# KANIT

Tarih: 2026-11-03. Ekran görüntüleri ve çıktılar `kanit/` klasöründedir.

## Senaryo

| Adım | Sonuç | Kanıt |
|---|---|---|
| a) Yanlış parola reddi, kayıt | Geçti | `01-giris-hatali.png`, `02-panel-bos.png` |
| b) Çumra'da haritaya gerçek tıklamayla parsel | Geçti, Konya / Çumra bulundu | `03-parsel-cizim.png` |
| c) Sentinel-2 NDVI, tarih, bulut | Geçti | `04-ndvi-isleniyor.png`, `05-ndvi.png` |
| d) Hava, 7 günlük tahmin, don uyarısı | Geçti | `06-hava-toprak.png` |
| e) Tahmini toprak, laboratuvarla değişen öneri | Geçti: buğday %70'ten %100'e | `06-hava-toprak.png`, `07-oneri.png` |
| f) Skor, neden, kaynak, gübre notu | Geçti, yalnızca pH eşiği ve tuzluluk kaynaklı | `07-oneri.png` |
| g) Verim ve fiyat gerçek; gider değişince kâr | Geçti, **giderler kullanıcı girişi** | `08`, `09`, `10` |
| h) Kaynak bağlantılı tohum kartları | Geçti | `11-bitki.png` |
| i) Kaynak durumu sayfası | Geçti | `12-kaynaklar.png` |
| Ana sayfa yönlendirmesi, mühendis raporu, telefon | Geçti | `13`, `14`, `16-rapor.png` |

Tam çıktı: `kanit/senaryo-sonucu.txt`. Araç: `kanit-arac/` (C#, Playwright, kurulu Chrome).

## Doğruluk karşılaştırması

| Konu | Beklenen | Bulunan | Fark | Yöntem |
|---|---|---|---|---|
| NDVI, demo parseli, 2026-10-24 | 0,1852 | 0,1852 | 0,0000 | Aynı sahne, Planetary Computer, rasterio ile ayrı hesap; 2650 hücre |
| Hava, 7 günün en düşük/yüksek değerleri | Open-Meteo API | Sistem önbelleği | 0 | Aynı koordinatla doğrudan çağrı |
| Alan, 1 km × 1 km | 1000 dönüm | 1000,0000 | 0 | Birim test |
| Kâr: 263 × 16,50 − 3000 | 1339,50 | 1339,50 | 0 | Elle hesap, tarayıcıda |
| Kâr: 263 × 16,50 − 3300 | 1039,50 | 1039,50 | 0 | Gider değiştirilerek |
| pH eşikleri 5,9 / 6,0 / 6,1 / 7,5 / 7,6 | 70 / 100 / 100 / 100 / 70 | Aynı | 0 | Birim test |

### Bulunup düzeltilen hata: NDVI

İlk karşılaştırmada sistem **0,3857**, bağımsız hesap **0,1852** verdi. Neden: Earth Search dosyalarında reflektans ofseti zaten uygulanmış (`earthsearch:boa_offset_applied: true`; iki kaynağın ham değer farkı tam 1000), metadata ise yine `offset: -0.1` diyor. Kod ofseti iki kez uyguluyordu. Düzeltildi, test eklendi, fark 0,0000 oldu.

Copernicus Browser ile karşılaştırma yapılmadı; bağımsız yol olarak Planetary Computer kullanıldı.

## Testler

46 otomatik testin hepsi geçti: `kanit/test-sonucu.txt`.

Kod bilerek bozuldu, testler kaldı, kod geri alındı (`kanit/bozma-testi.txt`):

| Bozma | Kalan test |
|---|---|
| NDVI formülü | 2 |
| Kâr formülü | 3 |
| pH sınır karşılaştırması | 1 |
| Parsel sahiplik kontrolü | 1 |

## İnternet kesintisi

Gerçek kesinti yerine dış istekler kapalı bir vekil sunucuya yönlendirilerek taklit edildi (`kanit/internetsiz.txt`). Site açıldı (200), hava "önbellekten, tarih ..." etiketiyle geldi, NDVI göründü, uydu kataloğu "erişilemiyor" oldu. SoilGrids ve Nominatim, önbellekleri taze olduğu için "çalışıyor" göründü; bu sırada gerçek bağlantı denenmedi. Harita altlığı OSM kuralı gereği önbelleğe alınmaz, internetsiz görünmez.

Dış çağrı kaydı: `logs/dis-api.log`, örnek `kanit/dis-api-ornek.txt` (kaynak, durum kodu, süre).

## Bilinen eksikler

- **Konya için kalem kalem maliyet yok.** Resmî tablo bulunamadı; kullanıcı girer. Referans toplamlar başka yörelerden ve ikincil kaynaktandır.
- **Nem ve fosfor eşiği yok.** Kaynak bulunamadı; bu kurallar "değerlendirilemedi" der.
- **Skor ağırlıkları proje kararıdır**, bilimsel kaynak değil. Eşikler optimal aralıktır; yerel çeşitlere özgü değildir.
- **Nohut, mercimek** eşiği yok; **ayçiçeği** için eşik var, fiyat ve verim yok.
- TMO fiyatı alım fiyatıdır, destek ve piyasa farkını içermez. Güncel yıl verimi kuraklık gibi etkiler taşıyabilir.
- SoilGrids ~250 m model verisidir, ölçüm değildir.
- Bulut oranı tüm sahneye aittir; parsel üstündeki yerel bulut ayrıca elenmez.
- Gübre kurallarının kaynakları Türkiye'ye özgü değildir (UC Davis, SEFARI, FAO). Doz verilmez.
- Gübre/girdi fiyatı, MGM, Türkiye'ye özel toprak veri tabanı: doğrulanamadı.
- Günlük yenileme kodu 24 saat boyunca çalıştırılarak denenmedi.
- **Yok:** yapay zekâ modeli, toprağın 10 m derin analizi, yayına alma. Yazarken anında kâr da yok; kâr Hesapla ile güncellenir.
- Uydu altlığı Esri World Imagery'dir; anahtarsız kullanım koşulları doğrulanamadı, Esri çalışanları forumda lisans gerektiğini yazmıştır. Kadastro seçimi TKGM'nin belgelenmemiş servisini kullanır, koşulları doğrulanamadı ve resmî belge değildir. İkisi de yalnızca yerel ders demosu içindir (`03b`, `03c`).
- Harita fareyle sürüklenir (`03a-harita-suruklendi.png`, Blazor Server). Bu özellik .NET'in `blazor.server.js` dosyasını kullanır ve sunucuyla canlı bağlantı ister. Telefonda parmakla sürükleme yoktur.
