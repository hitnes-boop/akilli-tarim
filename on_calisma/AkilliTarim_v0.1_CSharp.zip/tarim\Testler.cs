// Otomatik testler: dotnet run -- test. Geçici veritabanı kullanır; test verisi gerçek veritabanına yazılmaz.
using System.Net;
using System.Text.RegularExpressions;

namespace AkilliTarim;

public static class Testler
{
    static int gecen, kalan;
    static void T(string ad, bool ok) { if (ok) gecen++; else kalan++; Console.WriteLine($"{(ok ? "GEÇTİ" : "KALDI")}  {ad}"); }
    static bool Yakin(double a, double b, double e) => Math.Abs(a - b) <= e;

    static readonly UrunGereksinim G = new("Test", 6.0, 7.5, 20, 40, "Orta", "Orta", "test", "test");
    static int P(double? ph) => Kural.Puanla(G, new(ph, "lab", 30, "lab", "Düşük", "Orta")).Puan;

    public static async Task<int> Calistir()
    {
        Db.Yol = Path.Combine(Path.GetTempPath(), "tarim-test-" + Guid.NewGuid().ToString("N") + ".db");
        DisKaynak.LogYolu = Path.Combine(Path.GetTempPath(), "tarim-test-log", "t.log");
        Db.Kur();

        // Alan: 1 km x 1 km kare UTM'de kurulur, enlem/boylama çevrilir; beklenen 1000 dönüm.
        var (mx, my) = Geo.Utm(new(37.57, 32.85), 36);
        var kare = new[] { (0, 0), (1000, 0), (1000, 1000), (0, 1000) }.Select(k => Geo.UtmTers(mx + k.Item1, my + k.Item2, 36, new(37.57, 32.85))).ToList();
        var alan = Geo.AlanDonum(kare);
        Console.WriteLine($"       (1 km kare alanı: {alan:F4} dönüm)");
        T("Alan: 1 km x 1 km = 1000 dönüm", Yakin(alan, 1000, 0.01));
        T("Alan: yanlış sıra da pozitif", Geo.AlanDonum(Enumerable.Reverse(kare).ToList()) > 0);
        T("UTM ileri/geri tutarlı", Yakin(Geo.UtmTers(mx, my, 36, new(37.5, 32.8)).Lat, 37.57, 1e-6));

        T("NDVI: (0,5-0,1)/(0,5+0,1)=0,6667", Yakin(Kural.Ndvi(0.1, 0.5), 2.0 / 3, 1e-9));
        T("NDVI: eşit bant = 0", Kural.Ndvi(0.3, 0.3) == 0);
        T("Reflektans: ofset uygulanmışsa tekrar çıkarılmaz", Yakin(Kural.Reflektans(1634, 1e-4, -0.1, true), 0.1634, 1e-9));
        T("Reflektans: ofset uygulanmamışsa çıkarılır", Yakin(Kural.Reflektans(2634, 1e-4, -0.1, false), 0.1634, 1e-9));
        T("NDVI: sıfıra bölme NaN", double.IsNaN(Kural.Ndvi(0, 0)));

        T("Skor: pH tam alt eşik 6,0 = 100", P(6.0) == 100);
        T("Skor: pH alt eşik altı 5,9 = 70", P(5.9) == 70);
        T("Skor: pH 6,1 = 100", P(6.1) == 100);
        T("Skor: pH tam üst eşik 7,5 = 100", P(7.5) == 100);
        T("Skor: pH üst eşik üstü 7,6 = 70", P(7.6) == 70);
        T("Skor: tuz fazla -25", Kural.Puanla(G, new(7, "lab", 30, "lab", "Yüksek", "Orta")).Puan == 75);
        T("Skor: fosfor az -15", Kural.Puanla(G, new(7, "lab", 30, "lab", "Düşük", "Düşük")).Puan == 85);
        var eksik = Kural.Puanla(G, new(7, "t", null, "", null, null));
        T("Skor: eksik veri değerlendirilemedi", eksik.Degerlendirilemeyen.Count == 3 && eksik.Puan == 100);

        T("Gübre: fosfor düşük notu", Kural.GubreNotlari(new(7, "", 30, "", "Düşük", "Düşük")).Count == 1);
        T("Gübre: pH 5,5 kireçleme", Kural.GubreNotlari(new(5.5, "", 30, "", "Düşük", "Orta")).Count == 1);
        T("Gübre: pH tam 5,6 not yok", Kural.GubreNotlari(new(5.6, "", 30, "", "Düşük", "Orta")).Count == 0);
        T("Gübre: tuz yüksek yıkama", Kural.GubreNotlari(new(7, "", 30, "", "Yüksek", "Orta")).Single().not.Contains("yıkama"));
        var k1 = Kural.Kar(100, 10, 400);
        T("Kâr: 100 kg x 10 TL - 400 = 600", k1.Gelir == 1000 && k1.Kar == 600);
        var sen = Kural.SenaryoOrani(new[] { 200.0, 300, 400 });
        T("Senaryo: 200/300/400 -> 1,333 ve 0,667", sen != null && Yakin(sen.Value.iyi, 4.0 / 3, 1e-9) && Yakin(sen.Value.kotu, 2.0 / 3, 1e-9));
        T("Senaryo: 2 yılda gösterilmez", Kural.SenaryoOrani(new[] { 200.0, 300 }) == null);

        // Adaptör davranışı: kapalı port kaynağın ulaşılamaz olmasını taklit eder.
        const string kapali = "http://127.0.0.1:9/x";
        var yok = await DisKaynak.Getir("TestKaynak", "a", kapali, "u", "", "");
        T("Adaptör: önbellek yoksa Veri yok", yok.Deger == null);
        T("Adaptör: durum erişilemiyor", (string?)Db.Oku("SELECT durum FROM kaynak_durum WHERE kaynak='TestKaynak'")[0]["durum"] == "erişilemiyor");
        DisKaynak.CacheYaz("TestKaynak", "a", "{\"d\":1}");
        var onb = await DisKaynak.Getir("TestKaynak", "a", kapali, "u", "", "");
        T("Adaptör: kaynak yoksa önbellek etiketli", onb.OnbellekMi && onb.Deger != null && onb.Tarih != null);
        T("Adaptör: durum önbellekte", (string?)Db.Oku("SELECT durum FROM kaynak_durum WHERE kaynak='TestKaynak'")[0]["durum"] == "önbellekte");

        // Güvenlik: gerçek HTTP istekleriyle.
        var app = Uygulama.Olustur("http://localhost:5099");
        await app.StartAsync();
        try
        {
            const string kok = "http://localhost:5099";
            using var ah = new HttpClientHandler { AllowAutoRedirect = false, CookieContainer = new CookieContainer() };
            using var c = new HttpClient(ah);
            T("Girişsiz panel 401", (await c.GetAsync(kok + "/Panel")).StatusCode == HttpStatusCode.Unauthorized);
            var a = Oturum.KullaniciEkle("a@test.tr", "parola-a-1234", "A");
            Oturum.KullaniciEkle("b@test.tr", "parola-b-1234", "B");
            var n = new List<Nokta> { new(37.57, 32.85), new(37.57, 32.86), new(37.56, 32.86) };
            var pid = Db.Calistir("INSERT INTO parcels(user_id,name,geojson,area_hesaplanan) VALUES(@p0,'<b>x</b>',@p1,1)", a, Geo.GeoJson(n));

            async Task<HttpResponseMessage> Giris(string e, string pw)
            {
                var sayfa = await c.GetStringAsync(kok + "/");
                var tok = Regex.Match(sayfa, "__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
                return await c.PostAsync(kok + "/?handler=Giris", new FormUrlEncodedContent(new Dictionary<string, string> { ["email"] = e, ["parola"] = pw, ["__RequestVerificationToken"] = tok }));
            }
            T("Yanlış parola 401", (await Giris("a@test.tr", "yanlis")).StatusCode == HttpStatusCode.Unauthorized);
            var dogru = await Giris("b@test.tr", "parola-b-1234");
            T("Doğru parola yönlendirir", dogru.StatusCode == HttpStatusCode.Redirect);
            T("Çerez HttpOnly", string.Join("", dogru.Headers.GetValues("Set-Cookie")).Contains("token=") && string.Join("", dogru.Headers.GetValues("Set-Cookie")).ToLower().Contains("httponly"));
            T("Başkasının parseli 404", (await c.GetAsync(kok + "/Detay?id=" + pid)).StatusCode == HttpStatusCode.NotFound);
            T("Başkasının maliyeti 404", (await c.GetAsync(kok + "/Maliyet?id=" + pid)).StatusCode == HttpStatusCode.NotFound);
            var pb = Db.Calistir("INSERT INTO parcels(user_id,name,geojson,area_hesaplanan) VALUES((SELECT id FROM users WHERE email='b@test.tr'),'<b>x</b>',@p0,1)", Geo.GeoJson(n));
            var detay = await c.GetStringAsync(kok + "/Detay?id=" + pb);
            T("Parsel adı HTML kaçışlı", !detay.Contains("<b>x</b>"));
            var tk = Regex.Match(detay, "__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
            async Task<HttpStatusCode> Lab(string ph) => (await c.PostAsync($"{kok}/Detay?id={pb}&handler=Lab", new FormUrlEncodedContent(new Dictionary<string, string> { ["ph"] = ph, ["nem"] = "30", ["tuz"] = "Orta", ["fosfor"] = "Orta", ["__RequestVerificationToken"] = tk }))).StatusCode;
            T("Hatalı pH 400", await Lab("15") == HttpStatusCode.BadRequest);
            T("Geçerli lab kaydı yönlendirir", await Lab("7") == HttpStatusCode.Redirect);
            T("Antiforgery olmadan POST 400", (await c.PostAsync($"{kok}/Detay?id={pb}&handler=Lab", new FormUrlEncodedContent(new Dictionary<string, string> { ["ph"] = "7" }))).StatusCode == HttpStatusCode.BadRequest);
            T("Kaynaksız öneri tablosu boş", Db.Oku("SELECT 1 FROM crop_requirements").Count == 0);
            T("Kaynaksız öneri: Veri yetersiz", (await c.GetStringAsync(kok + "/Detay?id=" + pb)).Contains("Veri yetersiz"));

            // İçe aktarma ve kâr sayfası: yalnızca geçici test veritabanında, elle hesaplanan sayılarla.
            string Csv(string icerik) { var y = Path.GetTempFileName(); File.WriteAllText(y, icerik); return y; }
            int Ic(string tur, string icerik) => Ice.Calistir(new[] { "import", "--tur", tur, "--dosya", Csv(icerik), "--kaynak", "TEST", "--kaynak-url", "https://test.invalid", "--tarih", "2026-01-01" });
            T("İçe aktarma: --kaynak zorunlu", Ice.Calistir(new[] { "import", "--tur", "fiyat", "--dosya", "x" }) == 2);
            T("İçe aktarma: yanlış başlık reddedilir", Ic("fiyat", "a,b\n1,2") == 2);
            Db.Calistir("UPDATE parcels SET il='TestIl' WHERE id=@p0", pb);
            Ic("fiyat", "urun,fiyat,birim,tarih\nTestUrun,10000,TL/ton,2026-01-01");
            Ic("verim", "urun,il,yil,verim_kg_da\nTestUrun,TestIl,2023,200\nTestUrun,TestIl,2024,300\nTestUrun,TestIl,2025,400");
            Ic("maliyet", "urun,il,kalem,tutar,birim,yil\n" + string.Join("\n", new[] { "Tohum", "Gübre", "İlaç", "Sulama", "İşçilik", "Makine" }.Select(k => $"TestUrun,TestIl,{k},100,TL/da,2025")));
            var mal = await c.GetStringAsync($"{kok}/Maliyet?id={pb}&urun=TestUrun");
            // 400 kg x 10 TL = 4000; gider 600; kâr 3400. Sayı biçimi işletim sistemi diline bağlı olabilir.
            T("Kâr sayfası: 4000 - 600 = 3400", Regex.IsMatch(mal, @"3[.,]?400[.,]00 TL/d"));
            T("Kâr sayfası: 3 yılla senaryo görünür", mal.Contains("Senaryolar"));
            var mtk = Regex.Match(mal, "__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
            await c.PostAsync($"{kok}/Maliyet?id={pb}", new FormUrlEncodedContent(new Dictionary<string, string> { ["urun"] = "TestUrun", ["Tohum"] = "300", ["Gübre"] = "100", ["İlaç"] = "100", ["Sulama"] = "100", ["İşçilik"] = "100", ["Makine"] = "100", ["__RequestVerificationToken"] = mtk }));
            var mal2 = await c.GetStringAsync($"{kok}/Maliyet?id={pb}&urun=TestUrun");
            T("Gider değişince kâr: 4000 - 800 = 3200", Regex.IsMatch(mal2, @"3[.,]?200[.,]00 TL/d"));
            Ic("gereksinim", "urun,ph_min,ph_max,nem_min,nem_max,tuz_max,fosfor_min\nTestUrun,6,7.5,20,40,Orta,Orta");
            T("Lab pH 7 ile skor 100", (await c.GetStringAsync(kok + "/Detay?id=" + pb)).Contains("TestUrun: %100"));
            await Lab("9");
            T("Lab pH 9 ile öneri değişir (70)", (await c.GetStringAsync(kok + "/Detay?id=" + pb)).Contains("TestUrun: %70"));
        }
        finally { await app.StopAsync(); }

        Console.WriteLine($"\nToplam: {gecen} GEÇTİ, {kalan} KALDI");
        return kalan == 0 ? 0 : 1;
    }
}
