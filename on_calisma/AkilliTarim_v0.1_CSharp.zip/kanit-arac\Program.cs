// Uçtan uca senaryo: kurulu Chrome ile siteyi gerçekten kullanır, ekran görüntüsü ve metin kanıtı üretir.
// Kullanım: dotnet run -- http://localhost:5077 ..\tarim\kanit
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Playwright;

var kok = args[0]; var klasor = args[1];
Directory.CreateDirectory(klasor);
Console.OutputEncoding = Encoding.UTF8;
var rapor = new StringBuilder();
int kalan = 0;
void Yaz(string s) { Console.WriteLine(s); rapor.AppendLine(s); }
void Kontrol(string ad, bool ok, string ek = "") { if (!ok) kalan++; Yaz($"{(ok ? "GEÇTİ" : "KALDI")}  {ad} {ek}"); }

using var pw = await Playwright.CreateAsync();
await using var tarayici = await pw.Chromium.LaunchAsync(new() { Channel = "chrome", Headless = true });
var ctx = await tarayici.NewContextAsync(new() { ViewportSize = new() { Width = 1366, Height = 900 }, Locale = "tr-TR" });
var s = await ctx.NewPageAsync();
var hatalar = new List<string>();
s.Console += (_, m) => { if (m.Type == "error" && !m.Text.Contains("tile.openstreetmap")) hatalar.Add(m.Text); };
async Task Foto(string ad) => await s.ScreenshotAsync(new() { Path = Path.Combine(klasor, ad + ".png"), FullPage = true });
// Harita karoları yavaş olabilir; belge hazır olunca devam edilir.
async Task Bekle() { await Task.Delay(1500); await s.WaitForLoadStateAsync(LoadState.DOMContentLoaded); }
async Task<string> Metin() => await s.Locator("body").InnerTextAsync();

// a) Giriş ve kayıt
await s.GotoAsync(kok + "/");
await s.FillAsync("#e", "yok@ornek.com"); await s.FillAsync("#p", "yanlis-parola");
await s.ClickAsync("form[action*='Giris'] button");
Kontrol("a) Yanlış parola reddedilir", (await Metin()).Contains("E-posta veya parola hatalı"));
await Foto("01-giris-hatali");
await s.ClickAsync("summary");
var eposta = $"senaryo{DateTime.Now:HHmmss}@ornek.com";
await s.FillAsync("#ka", "Senaryo Çiftçi"); await s.FillAsync("#ke", eposta); await s.FillAsync("#kp", "senaryo-parola-1");
await s.ClickAsync("form[action*='Kayit'] button");
Kontrol("a) Kayıt sonrası panele girer", s.Url.Contains("/Panel"));
hatalar.Clear(); // Yanlış parola denemesinin 401'i beklenen sonuçtur.
await Foto("02-panel-bos");

// b) Haritaya gerçek tıklamalarla Çumra'da parsel çizimi
await s.GotoAsync(kok + "/Parsel?lat=37.5700&lon=32.8500&z=15", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
await Task.Delay(3000); // Blazor bağlantısı kurulsun
var harita = s.Locator(".harita-canli");
var kutu = (await harita.BoundingBoxAsync())!;
var merkezOnce = await s.Locator(".merkez").InnerTextAsync();
var karoOnce = await s.Locator(".harita-canli img").First.GetAttributeAsync("style");
// Gerçek fare sürüklemesi: sola 200, yukarı 80 piksel
await s.Mouse.MoveAsync(kutu.X + 400, kutu.Y + 250);
await s.Mouse.DownAsync();
for (int i = 1; i <= 10; i++) { await s.Mouse.MoveAsync(kutu.X + 400 - 20 * i, kutu.Y + 250 - 8 * i); await Task.Delay(40); }
await s.Mouse.UpAsync();
await Task.Delay(800);
var merkezSonra = await s.Locator(".merkez").InnerTextAsync();
Kontrol("b) Harita sürüklenince merkez değişir", merkezOnce != merkezSonra, $"{merkezOnce} -> {merkezSonra}");
Kontrol("b) Sürükleme köşe eklemez", (await Metin()).Contains("Seçili nokta: 0"));
await Foto("03a-harita-suruklendi");
var zOnce = await s.Locator(".kaynak:has(.merkez)").InnerTextAsync();
await s.Mouse.MoveAsync(kutu.X + 300, kutu.Y + 200);
await s.Mouse.WheelAsync(0, -200);
await Task.Delay(800);
Kontrol("b) Tekerlek yakınlaştırır", zOnce != await s.Locator(".kaynak:has(.merkez)").InnerTextAsync());
await s.Mouse.WheelAsync(0, 200);
await Task.Delay(800);
Kontrol("b) Uydu altlığı varsayılan", (await s.Locator(".harita-canli img").First.GetAttributeAsync("src"))!.Contains("World_Imagery"));
await s.FillAsync("#yer", "Çumra, Konya");
await s.ClickAsync("button:has-text('Bul')");
await Task.Delay(2500);
Kontrol("b) Yer araması bulur", (await Metin()).Contains("Bulundu:"), Regex.Match(await Metin(), @"Bulundu:.*").Value);
await Task.Delay(3000);
await Foto("03b-uydu-arama");
// Şehir merkezinde toprak ve parsel verisi farklıdır; kadastro ve çizim tarım arazisinde denenir.
await s.GotoAsync(kok + "/Parsel?lat=37.5700&lon=32.8500&z=16", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
await Task.Delay(4000);
await harita.ClickAsync(new() { Position = new() { X = 480, Y = 280 } });
await Task.Delay(3000);
var kd = await Metin();
Kontrol("b) Kadastrodan parsel seçilir", kd.Contains("Ada ") && kd.Contains("TKGM") && !kd.Contains("Seçili nokta: 0"), Regex.Match(kd, @".*Ada .*").Value);
await Foto("03c-kadastro");
await s.ClickAsync("button:has-text('Temizle')");
await s.ClickAsync("button:has-text('Köşeleri kendim çizeyim')");
await Task.Delay(500);
foreach (var (x, y) in new[] { (300, 170), (480, 170), (480, 340), (300, 340) })
{
    await harita.ClickAsync(new() { Position = new() { X = x, Y = y } });
    await Task.Delay(500);
}
var parselMetin = await Metin();
Kontrol("b) Dört köşe seçildi", parselMetin.Contains("Seçili nokta: 4"));
await Foto("03-parsel-cizim");
await s.FillAsync("#ad", "Çumra senaryo parseli");
await s.ClickAsync("button:has-text('Tarlayı kaydet')");
await s.WaitForURLAsync("**/Detay?id=*", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
var detayUrl = s.Url;
var d = await Metin();
Kontrol("b) İl/ilçe koordinattan bulundu", d.Contains("Konya"), Regex.Match(d, @"Alan:.*").Value);

// c) NDVI
await s.ClickAsync("button:has-text('NDVI hesapla')");
await Bekle();
Kontrol("c) İlerleme göstergesi görünür", await s.Locator(".yukleniyor").CountAsync() > 0);
await Foto("04-ndvi-isleniyor");
for (int i = 0; i < 40 && !(await Metin()).Contains("Ortalama NDVI"); i++) { await Task.Delay(4000); if (!s.Url.Contains("Detay")) break; }
d = await Metin();
var ndviSatir = Regex.Match(d, @"Ortalama NDVI:.*").Value;
Kontrol("c) NDVI, tarih ve bulut oranı yazılı", ndviSatir.Contains("Görüntü tarihi") && ndviSatir.Contains("Bulut"), ndviSatir);
Kontrol("c) NDVI hücreleri haritada", await s.Locator(".harita-katman polygon").CountAsync() > 100);
await Foto("05-ndvi");

// d) Hava ve e) toprak
Kontrol("d) 7 günlük tahmin kaynaklı", d.Contains("Open-Meteo Tahmin") && d.Contains("En düşük"));
Kontrol("d) Son 30 gün özeti", d.Contains("Toplam yağış"), Regex.Match(d, @"Toplam yağış:.*").Value);
Kontrol("e) Tahmini toprak etiketli", d.Contains("~250 m") && d.Contains("SoilGrids"), Regex.Match(d, @"0-5 cm.*").Value);
var skorOnce = Regex.Match(d, @"Buğday: %\d+").Value;
Kontrol("e) Laboratuvar önerisi uyarısı", d.Contains("laboratuvar analizi önerilir"));
await Foto("06-hava-toprak");

// e) Laboratuvar değeri öneriyi değiştirir
await s.FillAsync("#ph", "6,5"); await s.FillAsync("#nem", "30");
await s.SelectOptionAsync("#tuz", "Düşük"); await s.SelectOptionAsync("#fos", "Düşük");
await s.ClickAsync("button:has-text('Kaydet')");
await Bekle();
d = await Metin();
var skorSonra = Regex.Match(d, @"Buğday: %\d+").Value;
Yaz($"       SoilGrids ile: {skorOnce} / Laboratuvar pH 6,5 ile: {skorSonra}");
Kontrol("e) Lab değeri skoru değiştirir", skorOnce != skorSonra && skorSonra != "");

// f) Öneri
Kontrol("f) Neden ve kaynak yazılı", d.Contains("laboratuvar") && d.Contains("FAO") && d.Contains("Değerlendirilemedi"));
Kontrol("f) Gübre notu kaynaklı ve mühendis uyarısı", d.Contains("fosforlu gübre") && d.Contains("UC Davis") && d.Contains("Kesin doz için ziraat mühendisine danışın"));
await Foto("07-oneri");

// Hatalı girdi
await s.FillAsync("#ph", "15"); await s.FillAsync("#nem", "30");
await s.ClickAsync("button:has-text('Kaydet')");
await Bekle();
Kontrol("Hatalı pH anlaşılır mesaj", (await Metin()).Contains("pH 3 ile 10 arasında"));
hatalar.Clear(); // Hatalı girdinin 400'ü beklenen sonuçtur.

// g) Maliyet: gerçek verim ve fiyat; giderler kullanıcının girdiği değer
var id = Regex.Match(detayUrl, @"id=(\d+)").Groups[1].Value;
await s.GotoAsync($"{kok}/Maliyet?id={id}&urun={Uri.EscapeDataString("Buğday")}");
var m = await Metin();
Kontrol("g) Verim TÜİK'ten", m.Contains("263") && m.Contains("TÜİK"));
Kontrol("g) Fiyat TMO'dan", m.Contains("16,50 TL/kg") && m.Contains("TMO"));
Kontrol("g) Gider girilmeden kâr gösterilmez", m.Contains("Kâr: Veri yok"));
await Foto("08-maliyet-gidersiz");
foreach (var k in new[] { "Tohum", "Gübre", "İlaç", "Sulama", "İşçilik", "Makine" }) await s.FillAsync($"[id='{k}']", "500");
await s.ClickAsync("button:has-text('Hesapla')");
await Bekle();
m = await Metin();
// Elle: 263 x 16,5 = 4339,5; 6 x 500 = 3000; kâr 1339,5
Kontrol("g) Kâr: 4339,50 - 3000 = 1339,50", m.Contains("1.339,50"));
Kontrol("g) 10 yıllık verimle senaryo", m.Contains("Senaryolar"));
await Foto("09-maliyet-kar");
await s.FillAsync("[id='Gübre']", "800");
await s.ClickAsync("button:has-text('Hesapla')");
await Bekle();
m = await Metin();
Kontrol("g) Gider değişince kâr: 4339,50 - 3300 = 1039,50", m.Contains("1.039,50"));
await Foto("10-maliyet-degisti");

// h) Kütüphane, i) Durum
await s.GotoAsync(kok + "/Bitki");
var b = await Metin();
Kontrol("h) Üç kaynaklı kart", b.Contains("Siyez") && b.Contains("Kavılca") && b.Contains("Karakılçık") && await s.Locator(".kaynak a").CountAsync() == 3);
await Foto("11-bitki");
await s.GotoAsync(kok + "/Kaynaklar");
var k2 = await Metin();
Kontrol("i) Kaynak durumu çalışıyor", k2.Contains("çalışıyor") && k2.Contains("Sentinel-2"));
await Foto("12-kaynaklar");

await s.GotoAsync($"{kok}/Rapor?id={id}");
var rp = await Metin();
Kontrol("Mühendis raporu kaynaklı", rp.Contains("Sentinel") && rp.Contains("ziraat mühendisine") && rp.Contains("Laboratuvar: pH"));
await Foto("16-rapor");
await s.GotoAsync(kok + "/Panel", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
var an = await Metin();
Kontrol("Ana sayfa yönlendirir", an.Contains("Bugün ne yapmalıyım?") && an.Contains("Tamam"));
Kontrol("Ana sayfa ayrıntılı", an.Contains("Bekleyen iş") && an.Contains("Don riskli tarla") && an.Contains("Son laboratuvar pH"));
Kontrol("Yan menüde tarla listesi", await s.Locator(".menu a:has-text('Çumra senaryo parseli')").CountAsync() == 1);
await Foto("13-panel");
await s.SetViewportSizeAsync(390, 800);
await s.ReloadAsync(); await Foto("14-telefon-panel");
var tasma = await s.EvaluateAsync<bool>("document.documentElement.scrollWidth > window.innerWidth + 1");
Kontrol("Telefonda yatay taşma yok", !tasma);
await s.SetViewportSizeAsync(1366, 900);
await s.GotoAsync(kok + "/Parsel", new() { WaitUntil = WaitUntilState.DOMContentLoaded }); await Task.Delay(3000); await Foto("15-parsel-bos");
Kontrol("Tarayıcı konsolunda site hatası yok", hatalar.Count == 0, string.Join(" | ", hatalar.Take(3)));

// Yetki: oturumsuz bağlam
var ctx2 = await tarayici.NewContextAsync();
var yanit = await ctx2.APIRequest.GetAsync(kok + "/Panel", new() { MaxRedirects = 0 });
Kontrol("Girişsiz panel 401", yanit.Status == 401);

Yaz($"\nToplam KALDI: {kalan}");
File.WriteAllText(Path.Combine(klasor, "senaryo-sonucu.txt"), rapor.ToString());
return kalan == 0 ? 0 : 1;
