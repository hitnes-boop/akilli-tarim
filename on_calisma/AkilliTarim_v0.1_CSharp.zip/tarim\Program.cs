// Giriş noktası.
// dotnet run                -> siteyi başlatır (http://localhost:5000)
// dotnet run -- hazirlik    -> demo hesabı kurar, gerçek verilerle önbelleği doldurur
// dotnet run -- import ...  -> resmî CSV dosyasını içe aktarır
// dotnet run -- test        -> otomatik testler
using AkilliTarim;

Console.OutputEncoding = System.Text.Encoding.UTF8;
// Sayı ve tarihler arayüzde Türkçe biçimde yazılır.
var tr = new System.Globalization.CultureInfo("tr-TR");
System.Globalization.CultureInfo.DefaultThreadCurrentCulture = tr;
System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = tr;
if (args.FirstOrDefault() == "test") return await Testler.Calistir();
Db.Kur();
if (args.FirstOrDefault() == "import") return Ice.Calistir(args);
if (args.FirstOrDefault() == "parola" && args.Length == 3) return Oturum.ParolaDegistir(args[1], args[2]);
Ice.HazirVeriyiYukle();
if (args.FirstOrDefault() == "hazirlik") return await Uygulama.Hazirlik();

await Adaptor.BaslangicKontrolu();
var port = Environment.GetEnvironmentVariable("TARIM_PORT") ?? "5000";
var app = Uygulama.Olustur("http://localhost:" + port);
_ = Task.Run(async () =>
{
    while (true)
    {
        await Task.Delay(TimeSpan.FromHours(24));
        await Servis.GunlukYenile();
    }
});
Console.WriteLine($"Akıllı Tarım çalışıyor: http://localhost:{port}  (Kapatmak için Ctrl+C)");
await app.RunAsync();
return 0;

public static class Uygulama
{
    public static WebApplication Olustur(string url)
    {
        var b = WebApplication.CreateBuilder();
        b.Logging.SetMinimumLevel(LogLevel.Warning);
        // blazor.server.js build'in varlık listesinden gelir; Production ortamında da açıkça yüklenmelidir.
        b.WebHost.UseStaticWebAssets();
        b.Services.AddRazorPages();
        b.Services.AddServerSideBlazor();
        b.WebHost.UseUrls(url);
        var a = b.Build();
        a.UseExceptionHandler("/Hata");
        a.UseStaticFiles();
        // Giriş gerektiren her istek, oturum yoksa 401 alır; tarayıcı giriş sayfasına yönlenir.
        a.Use(async (h, sonraki) =>
        {
            var y = h.Request.Path.Value ?? "/";
            // Blazor betiği açık sayfada gerekmez ama oturumlu istekte çerezle gelir; diğer her yol oturum ister.
            if (y is "/" or "/Index" or "/Hata" || Oturum.Kim(h) != null) { await sonraki(); return; }
            h.Response.StatusCode = 401;
            h.Response.ContentType = "text/html; charset=utf-8";
            await h.Response.WriteAsync("<!doctype html><meta charset=utf-8><meta http-equiv=refresh content=\"0;url=/\"><p>Önce <a href=\"/\">giriş yapmalısınız</a>.</p>");
        });
        a.MapRazorPages();
        a.MapBlazorHub();
        return a;
    }

    // Derse gelmeden çalıştırılır: demo hesabı ve Çumra'da demo parseli için gerçek veriyi önbelleğe alır.
    public static async Task<int> Hazirlik()
    {
        const string email = "demo@ornek.com";
        var u = Db.Oku("SELECT id FROM users WHERE email=@p0", email).FirstOrDefault();
        var id = u != null ? (long)u["id"]! : Oturum.KullaniciEkle(email, "tarla-fb465ac4805b", "Demo Çiftçi");
        var n = new List<Nokta> { new(37.5700, 32.8500), new(37.5700, 32.8560), new(37.5655, 32.8560), new(37.5655, 32.8500) };
        var geo = Geo.GeoJson(n);
        var m = Geo.Merkez(n);
        var konum = await Adaptor.Konum(m);
        var (il, ilce) = KonumOku(konum);
        var p = Db.Oku("SELECT id FROM parcels WHERE user_id=@p0", id).FirstOrDefault();
        if (p == null) Db.Calistir("INSERT INTO parcels(user_id,name,geojson,area_hesaplanan,il,ilce) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", id, "Çumra demo parseli", geo, Geo.AlanDonum(n), il, ilce);
        await Adaptor.BaslangicKontrolu();
        await Adaptor.Tahmin(m, true); await Adaptor.Gecmis(m, true); await Adaptor.Toprak(m);
        Console.WriteLine("NDVI hesaplanıyor...");
        try { Console.WriteLine(Sentinel.Hesapla(n, geo) ?? "NDVI önbelleğe alındı."); }
        catch (Exception e) { DisKaynak.Log("Hazırlık NDVI HATA " + e); Console.WriteLine("NDVI alınamadı; ayrıntı logs/dis-api.log dosyasında."); }
        Console.WriteLine($"Demo hesabı: {email} / tarla-fb465ac4805b");
        return 0;
    }

    public static (string? il, string? ilce) KonumOku(Veri v)
    {
        if (v.Deger == null || !v.Deger.Value.TryGetProperty("address", out var a)) return (null, null);
        string? O(params string[] ad) { foreach (var x in ad) if (a.TryGetProperty(x, out var d)) return d.GetString(); return null; }
        return (O("province", "state"), O("town", "county", "city", "municipality"));
    }
}
