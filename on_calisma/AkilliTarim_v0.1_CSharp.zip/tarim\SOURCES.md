# Veri Kaynakları Keşfi (Aşama 0)

> **Güncelleme:** Bu belge ilk keşiftir. Sonradan Chrome ile doğrulananlar: TÜİK MEDAS Konya verimi 2016-2025 (buğday, arpa), TMO 2026 alım fiyatları (resmî PDF), FAO bitki kataloğu (pH, tuzluluk sınıfı), Karabak vd. 2019 ve Buğday Derneği (tohum). Aşağıdaki "doğrulanamadı" satırlarının güncel durumu için `KANIT.md`.

Test tarihi: 2026-11-03. Testler bu bilgisayardan yapıldı. Deneme noktaları Konya'dandır.

Durum etiketleri:

- **Doğrulandı:** Gerçek istek atıldı, gerçek veri alındı.
- **Kısmen:** Site açılıyor veya servis yanıt veriyor, ancak uygulamanın istediği veri alınmadı.
- **Doğrulanamadı:** Erişilemedi ya da bilgi teyit edilemedi.

## Özet

| # | İhtiyaç | Önerilen kaynak | Durum | Benden önce sizden gereken |
|---|---------|-----------------|-------|----------------------------|
| 1 | Uydu / NDVI | Earth Search + AWS Sentinel-2 COG | Kısmen (katalog ve bant dosyası okundu, NDVI henüz hesaplanmadı) | Yok |
| 2 | Harita altlığı | Leaflet + OSM | Doğrulandı | Yok |
| 3 | Hava | Open-Meteo | Doğrulandı | Yok |
| 4 | Toprak | SoilGrids REST | Doğrulandı (şehir içi noktada değer boş) | Yok |
| 5 | Verim | TÜİK | Kısmen (il/ilçe verisi alınmadı) | Dosya indirme |
| 6 | Maliyet | TEPGE ve benzeri yayınlar | Kısmen (güncel il bazlı tablo bulunamadı) | Kaynak kararı |
| 7 | Satış fiyatı | TMO | Kısmen (rakamlar yalnızca haberlerden görüldü) | Resmî belge |
| 8 | Gübre / girdi fiyatı | Yok | Doğrulanamadı | Kaynak kararı |
| 9 | Parsel / ada | Kullanıcı çizimi | Kullanılabilir | Yok |
| 10 | Ürün gereksinimleri (`crop_requirements`) | Yok | Doğrulanamadı | Kaynak kararı |
| 11 | Ata tohumları (`seeds`) | Aday makaleler | Kısmen (makaleler okunmadı) | Yok, ben okuyacağım |
| 12 | İl/ilçe bulma | Nominatim | Doğrulandı | Yok |

## 1. Uydu görüntüsü ve NDVI

### Earth Search + AWS Sentinel-2 COG (önerilen)

- **Adres:** `https://earth-search.aws.element84.com/v1/search`, dosyalar `sentinel-cogs.s3.us-west-2.amazonaws.com`
- **Erişim:** Açık API, anahtar gerekmiyor.
- **Test:** Konya noktası için 1892 kayıt bulundu. Bulut oranı %10'un altındaki son görüntü: `S2A_36SVG_20261019_1_L2A`, 2026-10-19, bulut %1,36. B04 ve B08 dosyalarından kısmi okuma çalıştı (HTTP 206).
- **Lisans:** Copernicus Sentinel verisi ücretsiz, tam ve açık (AWS Open Data kayıt sayfası).
- **Güncelleme:** Yeni görüntüler düzenli eklenir. Son kayıt 2026-11-01 tarihli.
- **Çözünürlük:** B04 ve B08 için 10 m (görev bilgisi; bu testte dosyadan ölçülmedi).
- **Henüz denenmedi:** Parsel kesitinin okunması ve NDVI hesabı.

### Alternatifler

| Kaynak | Sonuç | Not |
|--------|-------|-----|
| Copernicus Data Space (STAC, OData) | Katalog 200, anahtarsız | İndirme denenmedi; ücretsiz hesap ve aylık kota gerekir |
| Microsoft Planetary Computer STAC | Katalog 200, anahtarsız | Dosya erişimi denenmedi |

## 2. Harita altlığı

| Kaynak | Test | Kullanım koşulu |
|--------|------|-----------------|
| OpenStreetMap karoları | 200 | Görünür atıf ve kimlikli User-Agent zorunlu. **Toplu indirme ve çevrimdışı kullanım yasak.** |
| Leaflet 1.9.4 (unpkg) | 200 | Lisans bu çalışmada kontrol edilmedi |
| Esri World Imagery | 200 | **Koşullar doğrulanamadı** |
| EOX Sentinel-2 cloudless | 200 | **Koşullar doğrulanamadı** |

**Demo riski:** OSM karoları önceden indirilemez. İnternet kesilirse harita altlığı gelmez, ancak parsel çizimi ve NDVI hücreleri gösterilebilir.

## 3. Hava ve iklim

### Open-Meteo (önerilen)

- **Erişim:** Açık API, anahtar gerekmiyor. Tahmin ve arşiv uçları 200 döndü.
- **Test:** 7 günlük tahmin, toprak sıcaklığı, toprak nemi, Ekim 2026 sıcaklık ve yağışı alındı.
- **Lisans:** CC BY 4.0. Ticari olmayan kullanımda günde 10.000 çağrının altı ücretsiz.
- **Not:** Toprak sıcaklığı ve nemi ölçüm değil model çıktısıdır, arayüzde böyle etiketlenecek. API en yakın model hücresini döndürür; denemede istenen 37,87 / 32,50 için tahmin hücresi 37,87 / 32,48 oldu.
- **Güncelleme sıklığı ve çözünürlük:** Bu çalışmada teyit edilmedi.

### MGM

**Doğrulanamadı.** `www.mgm.gov.tr` ve `servis.mgm.gov.tr` bağlantıyı kesti. Herkese açık bir API olduğu da teyit edilmedi.

## 4. Toprak

### SoilGrids REST

- **Adres:** `https://rest.isric.org/soilgrids/v2.0/properties/query`
- **Erişim:** Açık API, anahtar gerekmiyor.
- **Çözünürlük:** ~250 m; model tahmini, ölçüm değil.
- **Lisans ve hız sınırı:** Okunan SSS sayfasında yok, **doğrulanamadı**.
- **Kararlılık:** İlk denemede DNS hatası alındı, sonraki denemelerde çalıştı. Önbellek gerekli.

0-5 cm derinlik için ham API değerleri:

| Nokta | pH (H2O) | Kil (g/kg) | Organik karbon (dg/kg) | İlçe (TKGM yanıtı) |
|-------|----------|------------|------------------------|---------------------|
| 37,57 / 32,85 | 7,3 | 328 | 306 | Çumra |
| 37,45 / 33,20 | 7,4 | 305 | 221 | Doğrulanmadı |
| 38,10 / 32,60 | 7,6 | 294 | 267 | Selçuklu |
| 37,87 / 32,50 (Konya merkezi) | **boş (null)** | Sorgulanmadı | Sorgulanmadı | Parsel bulunamadı |

**SoilGrids'te yok:** Tuz ve yararlı fosfor bu testte alınmadı. Bu iki değer yalnızca laboratuvar sonucundan gelecek; laboratuvar sonucu yoksa ilgili kural "değerlendirilemedi" diyecek. Nem için Open-Meteo'nun model değeri kullanılabilir, ama laboratuvar ölçümüyle aynı şey değildir.

### Türkiye'ye özel toprak veri tabanı

**Doğrulanamadı.** Açık erişimli bir kaynak bulunamadı.

## 5. Verim ve üretim

- **TÜİK veri portalı ve MEDAS:** Sayfalar açılıyor. **API ve il/ilçe verim verisi doğrulanamadı.**
- 2025 bitkisel üretim verilerinin 26 Aralık 2025'te yayımlandığı haberlerden görüldü.
- **FAOSTAT API:** 401 döndü. Ülke düzeyindeki bir kaynak il bazlı verimin yerini tutmaz.

**Sonuç:** Dosya içe aktarma gerekiyor. Üç senaryo için aynı ilin birkaç yıllık verimi de gerekir.

## 6. Üretim maliyeti

TEPGE yayın arşivinde bulunanlar (PDF):

| Yayın | Yıl | Sorun |
|-------|-----|-------|
| Çukurova Bölgesinde Başlıca Tarla Ürünlerinin Üretim Maliyetleri, No 230 | 2014 | Eski, tek bölge |
| Bazı Bölgeler İçin Önemli Ürünlerde Girdi Kullanımı ve Üretim Maliyetleri, No 64 | 2001 | Çok eski |
| Maliyet Hesaplama Metodolojisi Rehberi, No 37 | 1999 | Yöntem rehberi, maliyet verisi değil |

**Güncel, resmî ve il bazlı tablo bulunamadı.** 2026 için görülen tek güncel rakam Adana Çiftçiler Birliği'nin haberlere yansıyan hesabı; resmî değil ve Konya için geçerli değil.

## 7. Satış fiyatı

- **TMO:** `www.tmo.gov.tr` curl ile 200 döndü. Python'un `urllib` isteği sertifika zinciri hatası verdi. Doğrulama kapatılmayacak.
- **2026 alım fiyatı:** Haberlerde 2. grup buğday 16.500 TL/ton, arpa 12.750 TL/ton. **TMO'nun kendi belgesinde teyit edilmedi, bu yüzden veritabanına eklenmeyecek.**
- **Bu fiyatlarda nohut, mercimek ve ayçiçeği görülmedi.** Kaynak bulunmazsa bu ürünlerin kârı "Veri yok" olur.
- **Hal Kayıt Sistemi:** curl 302 döndü, Python alan adını çözemedi. Veri erişimi **doğrulanamadı**.
- **TZOB:** curl 200, Python sertifika hatası. İçerik incelenmedi.

## 8. Gübre ve girdi fiyatları

**Doğrulanamadı.** Bu çalışmada resmî bir kaynak bulunamadı. Şimdilik "Veri yok" gösterilecek; kullanıcı gider kalemlerine kendi tutarını girebilecek.

## 9. Parsel / ada bilgisi

- **TKGM `cbsapi.tkgm.gov.tr`:** Gerçek parsel geometrisi ve ilçe bilgisi döndü (anahtarsız).
- **Kullanım koşulları doğrulanamadı** ve parsel verisi hassas olabilir. **Kullanılmayacak.**
- Kullanıcı parselini haritada kendisi çizecek.

## 10. Ürün gereksinimleri

**Doğrulanamadı.** Bu kural öneri motorunun tamamını etkiler.

- FAO ECOCROP aday, ancak buğday değerleri okunamadı. Bir R paketi belgesi bu değerlerin uzman görüşü olduğunu belirtiyor.
- USDA NRCS belgesinde tuzluluk için dS/m cinsinden değerler var. Birimi uygulamadaki Düşük/Orta/Yüksek ile doğrudan eşleşmiyor.

Kaynak teyit edilene kadar tablo boş kalacak ve öneri "veri yetersiz" diyecek.

## 11. Ata tohumları

Adaylar bulundu, henüz okunmadı. Yalnızca okunup doğrulanan bilgi kartlara girecek.

- WWF Türkiye, Anadolu buğday genetik kaynakları sunumu
- DergiPark'taki Siyez ve Kavılca makaleleri
- Buğday Derneği, Hatay Karakılçık belgesi

## 12. İl/ilçe bulma

- **Nominatim:** Açık API, anahtar gerekmiyor. Test: `province: Konya`, `town: Meram`.
- **Lisans:** ODbL, atıf gerekli.
- **Koşul:** En fazla saniyede 1 istek, kimlikli User-Agent, sonuçları önbelleğe alma.

## Bağlantılar

- Sentinel-2 on AWS: https://registry.opendata.aws/sentinel-2-l2a-cogs/
- CDSE koşulları: https://dataspace.copernicus.eu/node/10
- OSM karo politikası: https://operations.osmfoundation.org/policies/tiles/
- Nominatim politikası: https://operations.osmfoundation.org/policies/nominatim/
- Open-Meteo koşulları: https://open-meteo.com/en/terms
- SoilGrids SSS: https://docs.isric.org/globaldata/soilgrids/SoilGrids_faqs.html
- TEPGE yayın arşivi: https://arastirma.tarimorman.gov.tr/tepge/Menu/53/Yayin-Arsivi
- TMO fiyat haberi: https://www.bloomberght.com/tmo-2026-yili-hububat-alim-ve-satis-fiyatlarini-acikladi-3778801
- Ecocrop parametreleri: https://search.r-project.org/CRAN/refmans/Recocrop/html/parameters.html
- USDA NRCS belgesi: https://webarchive.library.unt.edu/web/20170128032421/https://www.nrcs.usda.gov/Internet/FSE_PLANTMATERIALS/publications/azpmstn10485.pdf
- WWF sunumu: https://wwftr.awsassets.panda.org/downloads/2__sunum_gd_anadoluda_buday_genetik_kaynaklari_ve_havrani_16_mays2017.pdf
- Karakılçık belgesi: https://iklimdostuciftlikler.bugday.org/kaynaklar/hatay/Hatay%20-%20Karak%C4%B1l%C3%A7%C4%B1k%20Bu%C4%9Fday%C4%B1.pdf
