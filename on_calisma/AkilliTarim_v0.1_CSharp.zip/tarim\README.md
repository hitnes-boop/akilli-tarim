# Akıllı Tarım Platformu

C#, HTML ve CSS ile yazılmıştır; proje için JavaScript, Python veya PHP yazılmamıştır. Sürüklenen harita Blazor Server kullanır, bu yüzden .NET'in kendi `blazor.server.js` dosyası tarayıcıya yüklenir. Yerelde çalışır. SQLite sorguları C# içinde SQL metni olarak bulunur.

## Gerekenler

- .NET SDK (`net10.0` hedeflenir; bu bilgisayarda 11 RC SDK ve 10 çalışma zamanı ile denendi)
- İlk derleme için internet (NuGet paketleri)

## Çalıştırma

`tarim` klasöründe:

```bash
dotnet run
```

Sonra tarayıcıda http://localhost:5000 adresini açın.

## Derse gelmeden önce

Demo hesabını kurar ve gerçek verilerle önbelleği doldurur:

```bash
dotnet run -- hazirlik
```

Demo hesabı: `demo@ornek.com` / `tarla-fb465ac4805b`

İnternet giderse veriler "önbellekten, tarih ..." etiketiyle gelir. Harita altlığı önbelleğe alınmaz (OSM kuralı) ve görünmez; NDVI hücreleri görünmeye devam eder.

## Testler

```bash
dotnet run -- test
```

Testler geçici veritabanı kullanır, `tarim.db` dosyasına dokunmaz.

## Resmî dosya içe aktarma

Dosyayı `data/imports/` içine koyun. CSV, UTF-8 ve virgül ayraçlı olmalı; ondalık ayıracı noktadır.

```bash
dotnet run -- import --tur fiyat --dosya data/imports/tmo.csv --kaynak "TMO" --kaynak-url "https://..." --tarih 2026-06-02
```

| --tur | Başlık satırı | Birim |
|---|---|---|
| fiyat | `urun,fiyat,birim,tarih` | `TL/kg` veya `TL/ton` |
| maliyet | `urun,il,kalem,tutar,birim,yil` | `TL/da`; kalem: Tohum, Gübre, İlaç, Sulama, İşçilik, Makine |
| verim | `urun,il,yil,verim_kg_da` | kg/dekar |
| gereksinim | `urun,ph_min,ph_max,nem_min,nem_max,tuz_max,fosfor_min` | tuz/fosfor: Düşük, Orta, Yüksek |
| tohum | `name,description,region_note` | |

## Sayfalar

| Sayfa | İş |
|---|---|
| `/` | Giriş ve kayıt |
| `/Panel` | Parsel listesi ve özet |
| `/Parsel` | Haritaya tıklayarak parsel çizme |
| `/Detay?id=` | NDVI, hava, toprak, laboratuvar girişi, öneri |
| `/Maliyet?id=` | Maliyet, fiyat, verim, kâr, senaryolar |
| `/Rapor?id=` | Mühendise götürülecek yazdırılabilir özet |
| `/Bitki` | Kaynaklı tohum kartları |
| `/Kaynaklar` | Kaynakların durumu |

## JavaScript olmamasının sonuçları

- Harita fareyle sürüklenir ve tekerlekle yakınlaşır. Telefonda parmakla sürükleme yoktur; yön düğmeleri kullanılır.
- Kâr yazarken değil, **Hesapla** düğmesine basınca güncellenir.
- NDVI ilerlemesi için sayfa birkaç saniyede bir kendini yeniler.
