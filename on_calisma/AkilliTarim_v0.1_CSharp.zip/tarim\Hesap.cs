// Saf hesaplar: alan, harita izdüşümü, UTM, NDVI, öneri skoru ve kâr. Dış bağlantı yok; test edilir.
using System.Globalization;
using System.Text;

namespace AkilliTarim;

public record Nokta(double Lat, double Lon);

public static class Geo
{
    const double A = 6378137.0, F = 1 / 298.257223563;
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    // "lat,lon;lat,lon" metnini ayrıştırır; biçim veya Türkiye sınırı dışı ise boş liste döner.
    public static List<Nokta> Coz(string? metin)
    {
        var l = new List<Nokta>();
        if (string.IsNullOrWhiteSpace(metin)) return l;
        foreach (var p in metin.Split(';', StringSplitOptions.RemoveEmptyEntries))
        {
            var s = p.Split(',');
            if (s.Length != 2 || !double.TryParse(s[0], NumberStyles.Float, Inv, out var la) || !double.TryParse(s[1], NumberStyles.Float, Inv, out var lo)
                || la < 35 || la > 43 || lo < 25 || lo > 46) return new();
            l.Add(new(la, lo));
        }
        return l.Count > Harita.AzamiKose ? new() : l;
    }

    public static string Yaz(IEnumerable<Nokta> n) => string.Join(";", n.Select(p => p.Lat.ToString("F6", Inv) + "," + p.Lon.ToString("F6", Inv)));

    public static string GeoJson(List<Nokta> n)
    {
        var k = n.Append(n[0]).Select(p => $"[{p.Lon.ToString("F6", Inv)},{p.Lat.ToString("F6", Inv)}]");
        return "{\"type\":\"Polygon\",\"coordinates\":[[" + string.Join(",", k) + "]]}";
    }

    public static Nokta Merkez(List<Nokta> n) => new(n.Average(p => p.Lat), n.Average(p => p.Lon));

    // WGS84 elipsoidinde UTM'e izdüşüp çokgen alanı (m²) hesaplar; 1 dönüm = 1000 m².
    public static double AlanDonum(List<Nokta> n)
    {
        int zon = (int)Math.Floor((Merkez(n).Lon + 180) / 6) + 1;
        var u = n.Select(p => Utm(p, zon)).ToList();
        double t = 0;
        for (int i = 0; i < u.Count; i++) { var a = u[i]; var b = u[(i + 1) % u.Count]; t += a.x * b.y - b.x * a.y; }
        return Math.Abs(t) / 2 / 1000;
    }

    // Enlem/boylam -> UTM (kuzey yarıküre), Snyder serisi.
    public static (double x, double y) Utm(Nokta p, int zon)
    {
        double k0 = 0.9996, e2 = F * (2 - F), ep2 = e2 / (1 - e2);
        double la = p.Lat * Math.PI / 180, lo0 = (zon * 6 - 183) * Math.PI / 180, lo = p.Lon * Math.PI / 180;
        double s = Math.Sin(la), c = Math.Cos(la), ta = Math.Tan(la);
        double N = A / Math.Sqrt(1 - e2 * s * s), T = ta * ta, C = ep2 * c * c, Q = c * (lo - lo0);
        double M = A * ((1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256) * la
            - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 * e2 * e2 / 1024) * Math.Sin(2 * la)
            + (15 * e2 * e2 / 256 + 45 * e2 * e2 * e2 / 1024) * Math.Sin(4 * la)
            - (35 * e2 * e2 * e2 / 3072) * Math.Sin(6 * la));
        double x = k0 * N * (Q + (1 - T + C) * Q * Q * Q / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * Math.Pow(Q, 5) / 120) + 500000;
        double y = k0 * (M + N * ta * (Q * Q / 2 + (5 - T + 9 * C + 4 * C * C) * Math.Pow(Q, 4) / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * Math.Pow(Q, 6) / 720));
        return (x, y);
    }

    // UTM -> enlem/boylam: ileri formülü Newton ile tersine çevirir (metre altı).
    public static Nokta UtmTers(double x, double y, int zon, Nokta tahmin)
    {
        double la = tahmin.Lat, lo = tahmin.Lon;
        for (int i = 0; i < 6; i++)
        {
            var f = Utm(new(la, lo), zon);
            var fa = Utm(new(la + 1e-5, lo), zon); var fo = Utm(new(la, lo + 1e-5), zon);
            double a = (fa.x - f.x) / 1e-5, b = (fo.x - f.x) / 1e-5, c = (fa.y - f.y) / 1e-5, d = (fo.y - f.y) / 1e-5, det = a * d - b * c;
            double ex = x - f.x, ey = y - f.y;
            la += (d * ex - b * ey) / det; lo += (a * ey - c * ex) / det;
        }
        return new(la, lo);
    }

    public static bool Icinde(double x, double y, List<(double x, double y)> c)
    {
        bool ic = false;
        for (int i = 0, j = c.Count - 1; i < c.Count; j = i++)
            if ((c[i].y > y) != (c[j].y > y) && x < (c[j].x - c[i].x) * (y - c[i].y) / (c[j].y - c[i].y) + c[i].x) ic = !ic;
        return ic;
    }
}

// JavaScript olmadan harita: OSM karoları CSS arka planı, üstünde sunucunun çizdiği SVG.
public class Harita
{
    public const int G = 960, Y = 560;
    public const int AzamiKose = 500; // Gerçek kadastro parselleri çok köşeli olabilir.
    public double Lat, Lon; public int Z;
    double Dunya => 256 * Math.Pow(2, Z);
    public (double x, double y) DunyaPx(Nokta n)
    {
        double s = Math.Sin(n.Lat * Math.PI / 180);
        return ((n.Lon + 180) / 360 * Dunya, (0.5 - Math.Log((1 + s) / (1 - s)) / (4 * Math.PI)) * Dunya);
    }
    public (double x, double y) Ekran(Nokta n) { var m = DunyaPx(new(Lat, Lon)); var p = DunyaPx(n); return (p.x - m.x + G / 2.0, p.y - m.y + Y / 2.0); }
    public Nokta Tikla(double ex, double ey)
    {
        var m = DunyaPx(new(Lat, Lon));
        double x = m.x + ex - G / 2.0, y = m.y + ey - Y / 2.0;
        return new(Math.Atan(Math.Sinh(Math.PI * (1 - 2 * y / Dunya))) * 180 / Math.PI, x / Dunya * 360 - 180);
    }
    // Ekranı kaplayan karolar; aynı anahtar korunduğu için sürüklerken yeniden indirilmez.
    public List<(string anahtar, string adres, double sol, double ust)> Karolar(string sablon)
    {
        var m = DunyaPx(new(Lat, Lon));
        double sx = m.x - G / 2.0, sy = m.y - Y / 2.0;
        var l = new List<(string, string, double, double)>();
        for (int ty = (int)Math.Floor(sy / 256); ty * 256 < sy + Y; ty++)
            for (int tx = (int)Math.Floor(sx / 256); tx * 256 < sx + G; tx++)
                l.Add(($"{sablon}|{Z}/{tx}/{ty}", sablon.Replace("{z}", Z.ToString()).Replace("{x}", tx.ToString()).Replace("{y}", ty.ToString()), tx * 256 - sx, ty * 256 - sy));
        return l;
    }
}

public record UrunGereksinim(string Urun, double? PhMin, double? PhMax, double? NemMin, double? NemMax, string? TuzMax, string? FosforMin, string Kaynak, string KaynakUrl);
public record ToprakGirdi(double? Ph, string PhKaynak, double? Nem, string NemKaynak, string? Tuz, string? Fosfor);
public record Skor(string Urun, int Puan, List<string> Nedenler, List<string> Degerlendirilemeyen, string Kaynak, string KaynakUrl);
public record KarSonuc(double Gelir, double Gider, double Kar);

public static class Kural
{
    public static double Reflektans(int dn, double olcek, double ofset, bool ofsetUygulandi) => dn * olcek + (ofsetUygulandi ? 0 : ofset);

    public static double Ndvi(double kirmizi, double yakinKizilOtesi)
    {
        var t = yakinKizilOtesi + kirmizi;
        return t <= 0 ? double.NaN : (yakinKizilOtesi - kirmizi) / t;
    }

    static readonly string[] Seviye = { "Düşük", "Orta", "Yüksek" };
    public static bool SeviyeMi(string? s) => s != null && Seviye.Contains(s);

    // Ceza ağırlıkları projenin 5. hafta tasarımındandır (pH 30, nem 25, tuz 25); fosfor 15 proje kararıdır. Bilimsel iddia değildir.
    public static Skor Puanla(UrunGereksinim g, ToprakGirdi t)
    {
        int puan = 100; var n = new List<string>(); var d = new List<string>();
        if (t.Ph == null || g.PhMin == null || g.PhMax == null) d.Add("pH");
        else if (t.Ph < g.PhMin || t.Ph > g.PhMax) { puan -= 30; n.Add($"pH {t.Ph:0.0} ({t.PhKaynak}) aralık dışında ({g.PhMin:0.0}-{g.PhMax:0.0})"); }
        else n.Add($"pH {t.Ph:0.0} ({t.PhKaynak}) aralıkta");
        if (t.Nem == null || g.NemMin == null || g.NemMax == null) d.Add("nem");
        else if (t.Nem < g.NemMin || t.Nem > g.NemMax) { puan -= 25; n.Add($"Nem %{t.Nem:0.#} ({t.NemKaynak}) aralık dışında"); }
        else n.Add($"Nem %{t.Nem:0.#} ({t.NemKaynak}) aralıkta");
        if (t.Tuz == null || g.TuzMax == null) d.Add("tuzluluk");
        else if (Array.IndexOf(Seviye, t.Tuz) > Array.IndexOf(Seviye, g.TuzMax)) { puan -= 25; n.Add("Tuzluluk ürün sınırının üstünde"); }
        else n.Add("Tuzluluk sınır içinde");
        if (t.Fosfor == null || g.FosforMin == null) d.Add("fosfor");
        else if (Array.IndexOf(Seviye, t.Fosfor) < Array.IndexOf(Seviye, g.FosforMin)) { puan -= 15; n.Add("Fosfor ürün ihtiyacının altında"); }
        else n.Add("Fosfor yeterli");
        return new(g.Urun, puan, n, d, g.Kaynak, g.KaynakUrl);
    }

    // Gübre ve bakım notları yalnızca kaynağı okunmuş kurallardan gelir. Doz verilmez.
    public static List<(string not, string kaynak, string url)> GubreNotlari(ToprakGirdi t)
    {
        var n = new List<(string, string, string)>();
        if (t.Fosfor == "Düşük") n.Add(("Fosfor düşük: fosforlu gübre gündeme gelebilir; toprak ve bitki dokusu analiziyle doğrulayın.", "UC Davis Soil Health", "https://soilhealth.ucdavis.edu/soil-challenges/low-available-phosphorus"));
        if (t.Ph < 5.6) n.Add(("pH 5,6'nın altında: kök gelişimi sınırlanabilir; kireçleme pH'ı yükseltir.", "SEFARI", "https://sefari.scot/research/scotlands-harmful-acidic-soils-can-liming-improve-cropping-sustainability"));
        if (t.Tuz == "Yüksek") n.Add(("Tuzluluk yüksek: tuz kontrolünde temel yöntem yıkama sulamasıdır.", "FAO, Water Quality for Agriculture, 2.4.2", "https://www.fao.org/4/t0234e/t0234e03.htm"));
        return n;
    }

    public static KarSonuc Kar(double verimKgDa, double fiyatTlKg, double gider) { var gelir = verimKgDa * fiyatTlKg; return new(gelir, gider, gelir - gider); }

    // Senaryo oranları gerçek yılların en iyi/en kötü veriminin ortalamaya oranıdır; en az 3 yıl yoksa null.
    public static (double iyi, double kotu)? SenaryoOrani(IReadOnlyList<double> verimler)
    {
        if (verimler.Count < 3) return null;
        var ort = verimler.Average();
        return ort <= 0 ? null : (verimler.Max() / ort, verimler.Min() / ort);
    }
}
