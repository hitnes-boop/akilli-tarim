// Dış kaynak adaptörleri. Hepsi ortak Veri yapısını döndürür; kaynak değişirse sadece burası değişir.
using System.Collections.Concurrent;
using System.Globalization;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using BitMiracle.LibTiff.Classic;

namespace AkilliTarim;

public static class Adaptor
{
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    public static string K(Nokta n) => n.Lat.ToString("F4", Inv) + "," + n.Lon.ToString("F4", Inv);
    static string F(double d) => d.ToString("F5", Inv);
    static readonly TimeSpan Saat = TimeSpan.FromHours(1);

    public static Task<Veri> Konum(Nokta n) => DisKaynak.Getir("Nominatim (OpenStreetMap)", K(n),
        $"https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=tr&lat={F(n.Lat)}&lon={F(n.Lon)}",
        "https://www.openstreetmap.org/copyright", "", "Veri © OpenStreetMap katkıcıları, ODbL", TimeSpan.FromDays(30));

    // Yer adı arama (il, ilçe, köy); yalnızca kullanıcı "Bul" dediğinde çağrılır.
    public static Task<Veri> YerAra(string metin) => DisKaynak.Getir("Nominatim (OpenStreetMap)", "ara:" + metin.ToLowerInvariant(),
        $"https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=tr&accept-language=tr&q={Uri.EscapeDataString(metin)}",
        "https://www.openstreetmap.org/copyright", "", "Veri © OpenStreetMap katkıcıları, ODbL", TimeSpan.FromDays(30));

    // Tıklanan noktanın parseli (TKGM parsel sorgu servisi). Resmî belge yerine geçmez.
    public static Task<Veri> Kadastro(Nokta n) => DisKaynak.Getir("TKGM Parsel Sorgu", K(n),
        $"https://cbsapi.tkgm.gov.tr/megsiswebapi.v3/api/parsel/{F(n.Lat)}/{F(n.Lon)}/",
        "https://parselsorgu.tkgm.gov.tr/", "", "Bilgilendirme amaçlıdır; resmî belge değildir.", TimeSpan.FromDays(30));

    public static Task<Veri> Tahmin(Nokta n, bool taze = false) => DisKaynak.Getir("Open-Meteo Tahmin", K(n),
        $"https://api.open-meteo.com/v1/forecast?latitude={F(n.Lat)}&longitude={F(n.Lon)}&daily=temperature_2m_min,temperature_2m_max,precipitation_sum&forecast_days=7&timezone=auto",
        "https://open-meteo.com/", "°C, mm", "Model tahminidir (CC BY 4.0).", taze ? null : Saat);

    public static Task<Veri> Gecmis(Nokta n, bool taze = false)
    {
        var bit = DateTime.Today.AddDays(-2); var bas = bit.AddDays(-29);
        return DisKaynak.Getir("Open-Meteo Arşiv", K(n),
            $"https://archive-api.open-meteo.com/v1/archive?latitude={F(n.Lat)}&longitude={F(n.Lon)}&start_date={bas:yyyy-MM-dd}&end_date={bit:yyyy-MM-dd}&daily=temperature_2m_mean,precipitation_sum&timezone=auto",
            "https://open-meteo.com/", "°C, mm", "Yeniden analiz modeli (CC BY 4.0).", taze ? null : Saat);
    }

    public static Task<Veri> Toprak(Nokta n) => DisKaynak.Getir("SoilGrids (ISRIC)", K(n),
        $"https://rest.isric.org/soilgrids/v2.0/properties/query?lon={F(n.Lon)}&lat={F(n.Lat)}&property=phh2o&property=clay&property=soc&depth=0-5cm&value=mean",
        "https://soilgrids.org/", "", "Tahmini küresel toprak verisi, ~250 m; ölçüm değildir.", TimeSpan.FromDays(30));

    // SoilGrids yanıtından katman değerini okur; değer boşsa null.
    public static double? ToprakDeger(Veri v, string katman)
    {
        if (v.Deger == null) return null;
        foreach (var l in v.Deger.Value.GetProperty("properties").GetProperty("layers").EnumerateArray())
            if (l.GetProperty("name").GetString() == katman)
            {
                var m = l.GetProperty("depths")[0].GetProperty("values").GetProperty("mean");
                return m.ValueKind == JsonValueKind.Number ? m.GetDouble() / l.GetProperty("unit_measure").GetProperty("d_factor").GetDouble() : null;
            }
        return null;
    }

    // Başlangıç kontrolü: her kaynağı gerçekten dener, sonucu kaynak_durum tablosuna ve terminale yazar.
    public static async Task BaslangicKontrolu()
    {
        var n = new Nokta(37.57, 32.85);
        Console.WriteLine("Kaynak kontrolü:");
        var liste = new (string, Task<Veri>)[] { ("Open-Meteo Tahmin", Tahmin(n, true)), ("Open-Meteo Arşiv", Gecmis(n, true)), ("SoilGrids", Toprak(n)), ("Nominatim", Konum(n)) };
        foreach (var (ad, t) in liste)
        {
            var v = await t;
            Console.WriteLine($"  {ad}: {(v.Deger == null ? "ERİŞİLEMİYOR, önbellek yok" : v.OnbellekMi ? "ÖNBELLEKTEN (" + v.Tarih + ")" : "ÇALIŞIYOR")}");
        }
        try
        {
            using var y = await DisKaynak.Http.PostAsync(Sentinel.Stac, new StringContent("{\"collections\":[\"sentinel-2-l2a\"],\"limit\":1}", Encoding.UTF8, "application/json"));
            y.EnsureSuccessStatusCode();
            DisKaynak.Basarili(Sentinel.Ad, Sentinel.Url);
            Console.WriteLine("  Sentinel-2 kataloğu: ÇALIŞIYOR");
        }
        catch (Exception e) { DisKaynak.Log($"{Sentinel.Ad} HATA {e.Message}"); DisKaynak.Basarisiz(Sentinel.Ad, Sentinel.Url, false); Console.WriteLine("  Sentinel-2 kataloğu: ERİŞİLEMİYOR"); }
    }
}

// HTTP Range ile uzak GeoTIFF'in yalnızca gereken parçalarını okur.
class UzakTiff : TiffStream
{
    readonly string url; readonly long boyut; long konum; const int Blok = 512 * 1024;
    readonly Dictionary<long, byte[]> onbellek = new();
    public UzakTiff(string url)
    {
        this.url = url;
        var ilk = Getir(0);
        boyut = sonBoyut;
        onbellek[0] = ilk;
    }
    long sonBoyut;
    // Anlık ağ hatalarına karşı en çok üç kez dener.
    byte[] Getir(long blok)
    {
        for (int deneme = 1; ; deneme++)
        {
            try
            {
                var i = new HttpRequestMessage(HttpMethod.Get, url);
                i.Headers.Range = new RangeHeaderValue(blok * Blok, (blok + 1) * Blok - 1);
                using var y = DisKaynak.Http.Send(i);
                y.EnsureSuccessStatusCode();
                sonBoyut = y.Content.Headers.ContentRange?.Length ?? sonBoyut;
                using var m = new MemoryStream(); y.Content.ReadAsStream().CopyTo(m);
                return m.ToArray();
            }
            catch (HttpRequestException) when (deneme < 3) { Thread.Sleep(1000 * deneme); }
        }
    }
    public override int Read(object clientData, byte[] buffer, int offset, int count)
    {
        int oku = 0;
        while (oku < count && konum < boyut)
        {
            long b = konum / Blok;
            if (!onbellek.TryGetValue(b, out var d)) onbellek[b] = d = Getir(b);
            int ic = (int)(konum % Blok), n = Math.Min(count - oku, d.Length - ic);
            if (n <= 0) break;
            Array.Copy(d, ic, buffer, offset + oku, n);
            oku += n; konum += n;
        }
        return oku;
    }
    public override void Write(object clientData, byte[] buffer, int offset, int count) => throw new NotSupportedException();
    public override long Seek(object clientData, long offset, SeekOrigin origin)
    {
        konum = origin switch { SeekOrigin.Begin => offset, SeekOrigin.Current => konum + offset, _ => boyut + offset };
        return konum;
    }
    public override void Close(object clientData) { }
    public override long Size(object clientData) => boyut;
}

public static class Sentinel
{
    public const string Stac = "https://earth-search.aws.element84.com/v1/search";
    public const string Ad = "Sentinel-2 L2A (Earth Search / AWS)";
    public const string Url = "https://registry.opendata.aws/sentinel-2-l2a-cogs/";
    public static readonly ConcurrentDictionary<long, string> Isler = new();  // Çalışan NDVI işleri
    public static readonly ConcurrentDictionary<long, string> Hatalar = new();

    public static string Anahtar(string geojson) => Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(geojson)));

    // Yavaş iş arka planda koşar; sayfa bu sırada kendini yeniler, kullanıcı donmuş ekran görmez.
    public static void Baslat(long parselId, List<Nokta> n, string geojson)
    {
        if (!Isler.TryAdd(parselId, Db.Simdi())) return;
        Hatalar.TryRemove(parselId, out _);
        _ = Task.Run(async () =>
        {
            try
            {
                var is1 = Task.Run(() => Hesapla(n, geojson));
                if (await Task.WhenAny(is1, Task.Delay(TimeSpan.FromSeconds(120))) != is1) throw new TimeoutException();
                var mesaj = await is1;
                if (mesaj != null) Hatalar[parselId] = mesaj;
            }
            catch (Exception e)
            {
                DisKaynak.Log($"{Ad} HATA {e.GetType().Name}: {e.Message}");
                DisKaynak.Basarisiz(Ad, Url, DisKaynak.CacheOku(Ad, Anahtar(geojson)) != null);
                Hatalar[parselId] = e is TimeoutException ? "Uydu verisi zaman aşımına uğradı. Lütfen tekrar deneyin." : "Uydu verisine şu anda ulaşılamıyor.";
            }
            finally { Isler.TryRemove(parselId, out _); }
        });
    }

    // Son düşük bulutlu görüntüyü bulur, B04/B08'den 10 m hücrelerle NDVI hesaplar, önbelleğe yazar. Görüntü yoksa mesaj döner.
    public static string? Hesapla(List<Nokta> n, string geojson)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var govde = "{\"collections\":[\"sentinel-2-l2a\"],\"intersects\":" + geojson + ",\"limit\":1,\"query\":{\"eo:cloud_cover\":{\"lt\":10}},\"sortby\":[{\"field\":\"properties.datetime\",\"direction\":\"desc\"}]}";
        using var y = DisKaynak.Http.Send(new HttpRequestMessage(HttpMethod.Post, Stac) { Content = new StringContent(govde, Encoding.UTF8, "application/json") });
        DisKaynak.Log($"{Ad} STAC durum={(int)y.StatusCode} sure={sw.ElapsedMilliseconds}ms");
        y.EnsureSuccessStatusCode();
        using var d = JsonDocument.Parse(y.Content.ReadAsStream());
        var ozellik = d.RootElement.GetProperty("features");
        if (ozellik.GetArrayLength() == 0) return "Bu parsel için bulut oranı %10'un altında görüntü bulunamadı.";
        var f = ozellik[0]; var p = f.GetProperty("properties"); var a = f.GetProperty("assets");
        int epsg = p.GetProperty("proj:epsg").GetInt32();
        int zon = epsg - 32600;
        if (zon < 1 || zon > 60) throw new InvalidDataException("Beklenmeyen EPSG: " + epsg);
        var ut = n.Select(q => Geo.Utm(q, zon)).ToList();

        // Earth Search'te ofset dosyaya zaten uygulanmış olabilir; bu bayrak okunmazsa NDVI yanlış çıkar (bkz. KANIT.md).
        bool ofsetUygulandi = p.TryGetProperty("earthsearch:boa_offset_applied", out var bayrak) && bayrak.ValueKind == JsonValueKind.True;
        var kirmizi = Bant(a.GetProperty("red"), ut, ofsetUygulandi, out var ax, out var ay, out var genislik, out var satir, out var kol0, out var sat0);
        var nir = Bant(a.GetProperty("nir"), ut, ofsetUygulandi, out _, out _, out _, out _, out _, out _);

        var hucreler = new List<object>(); double top = 0;
        for (int s = 0; s < satir; s++)
            for (int c = 0; c < genislik; c++)
            {
                double x = ax + (kol0 + c + 0.5) * 10, yy = ay - (sat0 + s + 0.5) * 10;
                if (!Geo.Icinde(x, yy, ut)) continue;
                double r = kirmizi[s, c], ni = nir[s, c];
                if (double.IsNaN(r) || double.IsNaN(ni)) continue;
                var v = Kural.Ndvi(r, ni);
                if (double.IsNaN(v)) continue;
                hucreler.Add(new { x, y = yy, v = Math.Round(v, 4) }); top += v;
            }
        if (hucreler.Count == 0) return "Parsel içinde geçerli uydu hücresi yok (parsel 10 m hücreden küçük olabilir).";
        var sonuc = JsonSerializer.Serialize(new { goruntu = f.GetProperty("id").GetString(), tarih = p.GetProperty("datetime").GetString(),
            bulut = p.GetProperty("eo:cloud_cover").GetDouble(), ortalama = Math.Round(top / hucreler.Count, 4), zon, hucreler });
        DisKaynak.CacheYaz(Ad, Anahtar(geojson), sonuc);
        DisKaynak.Basarili(Ad, Url);
        DisKaynak.Log($"{Ad} NDVI hucre={hucreler.Count} toplam_sure={sw.ElapsedMilliseconds}ms");
        return null;
    }

    // Bir bandın parseli kapsayan penceresini reflektans olarak okur (geçersiz piksel NaN).
    static double[,] Bant(JsonElement varlik, List<(double x, double y)> ut, bool ofsetUygulandi, out double ax, out double ay, out int gen, out int yuk, out int kol0, out int sat0)
    {
        var t = varlik.GetProperty("proj:transform");
        if (t[0].GetDouble() != 10) throw new InvalidDataException("Bant 10 m değil.");
        ax = t[2].GetDouble(); ay = t[5].GetDouble();
        var rb = varlik.GetProperty("raster:bands")[0];
        double olcek = rb.TryGetProperty("scale", out var o) ? o.GetDouble() : 1e-4, ofset = rb.TryGetProperty("offset", out var of) ? of.GetDouble() : 0;
        kol0 = (int)Math.Floor((ut.Min(q => q.x) - ax) / 10); int kol1 = (int)Math.Floor((ut.Max(q => q.x) - ax) / 10);
        sat0 = (int)Math.Floor((ay - ut.Max(q => q.y)) / 10); int sat1 = (int)Math.Floor((ay - ut.Min(q => q.y)) / 10);
        gen = kol1 - kol0 + 1; yuk = sat1 - sat0 + 1;
        if (gen * yuk > 250_000) throw new InvalidDataException("Parsel çok büyük.");
        var cikti = new double[yuk, gen];
        using var tif = Tiff.ClientOpen("bant", "r", new object(), new UzakTiff(varlik.GetProperty("href").GetString()!)) ?? throw new InvalidDataException("TIFF açılamadı.");
        int tg = tif.GetField(TiffTag.TILEWIDTH)[0].ToInt(), ty = tif.GetField(TiffTag.TILELENGTH)[0].ToInt();
        var karolar = new Dictionary<int, byte[]>();
        for (int s = 0; s < yuk; s++)
            for (int c = 0; c < gen; c++)
            {
                int pk = kol0 + c, ps = sat0 + s;
                int idx = tif.ComputeTile(pk, ps, 0, 0);
                if (!karolar.TryGetValue(idx, out var b))
                {
                    b = new byte[tif.TileSize()];
                    tif.ReadEncodedTile(idx, b, 0, b.Length);
                    karolar[idx] = b;
                }
                int i = 2 * ((ps % ty) * tg + pk % tg);
                int dn = BitConverter.ToUInt16(b, i);
                cikti[s, c] = dn == 0 ? double.NaN : Kural.Reflektans(dn, olcek, ofset, ofsetUygulandi);
            }
        return cikti;
    }
}

public record Adim(string Metin, bool Bitti, string Bag, string Dugme);

public static class Servis
{
    // Çiftçiye sıradaki işi söyleyen yol haritası; yalnızca kayıtlı gerçek duruma bakar.
    public static List<Adim> Adimlar(Dictionary<string, object?> p)
    {
        var id = p["id"];
        return new()
        {
            new("Tarlanı haritada çiz", true, "/Parsel", "Tarla ekle"),
            new("Uydu görüntüsünü al", DisKaynak.CacheOku(Sentinel.Ad, Sentinel.Anahtar((string)p["geojson"]!)) != null, $"/Detay?id={id}#uydu", "Uyduya bak"),
            new("Toprak analiz sonucunu gir", Db.Oku("SELECT 1 FROM soil_measurements WHERE parcel_id=@p0", id).Count > 0, $"/Detay?id={id}#toprak", "Sonucu gir"),
            new("Giderlerini yaz, kârını gör", Db.Oku("SELECT 1 FROM user_costs WHERE parcel_id=@p0", id).Count > 0, $"/Maliyet?id={id}", "Gider yaz"),
        };
    }

    // Haftalık plan: son tahmindeki günler, en düşük sıcaklık ve yağış. Öneri değil, planlamaya yardımcı ham veridir.
    public static List<(string gun, double dusuk, double yagis)> HaftaPlani(List<Nokta> n)
    {
        var c = DisKaynak.CacheOku("Open-Meteo Tahmin", Adaptor.K(Geo.Merkez(n)));
        if (c == null) return new();
        var d = JsonDocument.Parse(c.Value.json).RootElement.GetProperty("daily");
        var t = d.GetProperty("time"); var m = d.GetProperty("temperature_2m_min"); var y = d.GetProperty("precipitation_sum");
        var bugun = DateTime.Today.ToString("yyyy-MM-dd");
        return Enumerable.Range(0, t.GetArrayLength())
            .Where(i => string.CompareOrdinal(t[i].GetString(), bugun) >= 0 && m[i].ValueKind == JsonValueKind.Number && y[i].ValueKind == JsonValueKind.Number)
            .Select(i => (t[i].GetString()!, m[i].GetDouble(), y[i].GetDouble())).ToList();
    }

    // Son çekilen tahminde önümüzdeki don günleri (en düşük sıcaklık 0 °C veya altı).
    public static List<string> DonGunleri(List<Nokta> n)
    {
        var c = DisKaynak.CacheOku("Open-Meteo Tahmin", Adaptor.K(Geo.Merkez(n)));
        if (c == null) return new();
        var d = JsonDocument.Parse(c.Value.json).RootElement.GetProperty("daily");
        var bugun = DateTime.Today.ToString("yyyy-MM-dd");
        var t = d.GetProperty("time"); var m = d.GetProperty("temperature_2m_min");
        return Enumerable.Range(0, t.GetArrayLength())
            .Where(i => m[i].ValueKind == JsonValueKind.Number && m[i].GetDouble() <= 0 && string.CompareOrdinal(t[i].GetString(), bugun) >= 0)
            .Select(i => t[i].GetString()!).ToList();
    }

    public static List<Nokta> ParselNoktalari(string geojson)
    {
        using var d = JsonDocument.Parse(geojson);
        var k = d.RootElement.GetProperty("coordinates")[0].EnumerateArray().Select(c => new Nokta(c[1].GetDouble(), c[0].GetDouble())).ToList();
        k.RemoveAt(k.Count - 1);
        return k;
    }

    // Zamanlanmış görev: günde bir hava ve uydu verisini yeniler. Hata olursa loga yazar, eski veri silinmez.
    public static async Task GunlukYenile()
    {
        foreach (var p in Db.Oku("SELECT id,geojson FROM parcels"))
        {
            try
            {
                var geo = (string)p["geojson"]!; var n = ParselNoktalari(geo); var m = Geo.Merkez(n);
                await Adaptor.Tahmin(m, true); await Adaptor.Gecmis(m, true);
                Sentinel.Baslat((long)p["id"]!, n, geo);
            }
            catch (Exception e) { DisKaynak.Log("Yenileme HATA " + e.Message); }
        }
    }

    // Laboratuvar sonucu varsa öncelikli, yoksa SoilGrids pH'ı kullanılır.
    public static ToprakGirdi Girdi(long parselId, Veri soil)
    {
        var l = Db.Oku("SELECT * FROM soil_measurements WHERE parcel_id=@p0 ORDER BY id DESC LIMIT 1", parselId).FirstOrDefault();
        var ph = l?["ph"] as double?;
        return ph != null || l != null
            ? new(ph ?? Adaptor.ToprakDeger(soil, "phh2o"), ph != null ? "laboratuvar" : "SoilGrids tahmini", l?["nem"] as double?, "laboratuvar", l?["tuz"] as string, l?["fosfor"] as string)
            : new(Adaptor.ToprakDeger(soil, "phh2o"), "SoilGrids tahmini", null, "", null, null);
    }

    public static List<Skor> Oneriler(ToprakGirdi t) => Db.Oku("SELECT * FROM crop_requirements").Select(r => Kural.Puanla(new(
        (string)r["urun"]!, r["ph_min"] as double?, r["ph_max"] as double?, r["nem_min"] as double?, r["nem_max"] as double?,
        r["tuz_max"] as string, r["fosfor_min"] as string, (string)r["kaynak"]!, (string)r["kaynak_url"]!), t)).OrderByDescending(s => s.Puan).ToList();
}

// Resmî dosyaları içe aktarır. Kaynak, bağlantı ve tarih zorunludur.
public static class Ice
{
    static readonly Dictionary<string, string[]> Sutunlar = new()
    {
        ["fiyat"] = new[] { "urun", "fiyat", "birim", "tarih" },
        ["maliyet"] = new[] { "urun", "il", "kalem", "tutar", "birim", "yil" },
        ["verim"] = new[] { "urun", "il", "yil", "verim_kg_da" },
        ["gereksinim"] = new[] { "urun", "ph_min", "ph_max", "nem_min", "nem_max", "tuz_max", "fosfor_min" },
        ["tohum"] = new[] { "name", "description", "region_note" },
    };
    static readonly Dictionary<string, string> Tablo = new() { ["fiyat"] = "price_data", ["maliyet"] = "cost_data", ["verim"] = "yield_data", ["gereksinim"] = "crop_requirements", ["tohum"] = "seeds" };

    // Projeyle gelen doğrulanmış dosyalar; ilgili tablo boşsa ilk çalıştırmada yüklenir.
    static readonly (string tur, string dosya, string kaynak, string url, string tarih)[] Hazir =
    {
        ("verim", "tuik-konya-verim.csv", "TÜİK MEDAS, Bitkisel Üretim İstatistikleri (Buğday: durum hariç; Arpa: diğer)", "https://biruni.tuik.gov.tr/medas/?kn=92&locale=tr", "2026-11-03"),
        ("fiyat", "tmo-2026-alim-fiyat.csv", "TMO 2026 Dönemi Hububat Alım Fiyatları, 2. grup; destekler hariç", "https://www.tmo.gov.tr/Upload/Document/alim/2023/hubmudalimfyt.pdf", "2026-06-09"),
        ("gereksinim", "fao-gereksinim.csv", "FAO, Catalogue of Crops used in BEFS RA, optimal aralık", "https://openknowledge.fao.org/server/api/core/bitstreams/ea76cc59-b73f-454b-8765-6aa5882a1a7f/content", "2026-11-03"),
        ("maliyet", "maliyet-referans.csv", "Tarım TR haberi: Adana Çiftçiler Birliği ve Lalapaşa Ziraat Odası hesapları (ikincil kaynak)", "https://www.tarimtr.com/bugday-ekimi-basladi-2026da-1-dekar-bugday-ekmek-kaca-mal-oluyor", "2026-11-03"),
        ("tohum", "tohum-siyez.csv", "Karabak vd. 2019, Toprak Su Dergisi", "https://dergipark.org.tr/en/download/article-file/873425", "2019-07-19"),
        ("tohum", "tohum-kavilca.csv", "Özkan ve Deniz 2025, Gaziantep Üniversitesi Sosyal Bilimler Dergisi", "https://dergipark.org.tr/en/download/article-file/4491167", "2025-03-25"),
        ("tohum", "tohum-karakilcik.csv", "Yücel, Karakılçık Buğdayı Rehberi, Buğday Derneği", "https://iklimdostuciftlikler.bugday.org/kaynaklar/hatay/Hatay%20-%20Karak%C4%B1l%C3%A7%C4%B1k%20Bu%C4%9Fday%C4%B1.pdf", "2026-11-03"),
    };

    public static void HazirVeriyiYukle()
    {
        foreach (var h in Hazir)
        {
            var yol = Path.Combine("data", "imports", h.dosya);
            if (Db.Oku($"SELECT 1 FROM {Tablo[h.tur]} WHERE kaynak LIKE @p0 LIMIT 1", h.kaynak + "%").Count > 0 || !File.Exists(yol)) continue;
            Calistir(new[] { "import", "--tur", h.tur, "--dosya", yol, "--kaynak", h.kaynak, "--kaynak-url", h.url, "--tarih", h.tarih });
        }
    }

    public static int Calistir(string[] a)
    {
        string? P(string ad) { var i = Array.IndexOf(a, ad); return i >= 0 && i + 1 < a.Length ? a[i + 1] : null; }
        string? tur = P("--tur"), dosya = P("--dosya"), kaynak = P("--kaynak"), url = P("--kaynak-url"), tarih = P("--tarih");
        if (tur == null || dosya == null || kaynak == null || url == null || tarih == null || !Sutunlar.ContainsKey(tur))
        {
            Console.WriteLine("Kullanım: dotnet run -- import --tur fiyat|maliyet|verim|gereksinim|tohum --dosya data/imports/x.csv --kaynak AD --kaynak-url URL --tarih YYYY-AA-GG");
            return 2;
        }
        var sut = Sutunlar[tur]; var satirlar = File.ReadAllLines(dosya);
        if (satirlar.Length < 1 || !satirlar[0].Trim().TrimStart('﻿').Split(',').SequenceEqual(sut)) { Console.WriteLine("Başlık satırı şu olmalı: " + string.Join(",", sut)); return 2; }
        int n = 0;
        foreach (var s in satirlar.Skip(1).Where(x => x.Trim() != ""))
        {
            var d = s.Split(',').Select(x => x.Trim()).ToArray();
            if (d.Length != sut.Length) { Console.WriteLine("Hatalı satır, durduruldu: " + s); return 2; }
            var ps = string.Join(",", Enumerable.Range(0, sut.Length + 2).Select(i => "@p" + i));
            var deg = d.Select(x => (object?)(double.TryParse(x, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) && !x.Contains('-') ? v : x == "" ? null : x)).ToList();
            deg.Add(kaynak + " (dosya tarihi " + tarih + ")"); deg.Add(url);
            Db.Calistir($"INSERT OR REPLACE INTO {Tablo[tur]}({string.Join(",", sut)},kaynak,kaynak_url) VALUES({ps})", deg.ToArray());
            n++;
        }
        Console.WriteLine($"{n} kayıt eklendi: {tur}");
        return 0;
    }
}
