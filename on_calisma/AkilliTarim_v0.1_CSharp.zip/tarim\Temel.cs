// Temel yardımcılar: veritabanı, parola/oturum ve dış kaynak önbelleği.
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace AkilliTarim;

public static class Db
{
    public static string Yol = Environment.GetEnvironmentVariable("TARIM_DB") ?? "tarim.db";

    public static SqliteConnection Ac()
    {
        var c = new SqliteConnection($"Data Source={Yol}");
        c.Open();
        using var k = c.CreateCommand();
        k.CommandText = "PRAGMA foreign_keys=ON";
        k.ExecuteNonQuery();
        return c;
    }

    // Her sorgu ? yerine @p0, @p1 parametreleri kullanır (SQL injection yok).
    static SqliteCommand Komut(SqliteConnection c, string sql, object?[] p)
    {
        var k = c.CreateCommand();
        k.CommandText = sql;
        for (int i = 0; i < p.Length; i++) k.Parameters.AddWithValue("@p" + i, p[i] ?? DBNull.Value);
        return k;
    }

    public static long Calistir(string sql, params object?[] p)
    {
        using var c = Ac();
        using var k = Komut(c, sql, p);
        k.ExecuteNonQuery();
        using var s = c.CreateCommand();
        s.CommandText = "SELECT last_insert_rowid()";
        return (long)s.ExecuteScalar()!;
    }

    public static List<Dictionary<string, object?>> Oku(string sql, params object?[] p)
    {
        using var c = Ac();
        using var k = Komut(c, sql, p);
        using var r = k.ExecuteReader();
        var liste = new List<Dictionary<string, object?>>();
        while (r.Read())
        {
            var d = new Dictionary<string, object?>();
            for (int i = 0; i < r.FieldCount; i++) d[r.GetName(i)] = r.IsDBNull(i) ? null : r.GetValue(i);
            liste.Add(d);
        }
        return liste;
    }

    public static void Kur() => Calistir(@"
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,hash TEXT NOT NULL,name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS parcels(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),name TEXT NOT NULL,geojson TEXT NOT NULL,area_hesaplanan REAL NOT NULL,il TEXT,ilce TEXT);
CREATE TABLE IF NOT EXISTS soil_measurements(id INTEGER PRIMARY KEY,parcel_id INTEGER NOT NULL REFERENCES parcels(id),ph REAL,nem REAL,tuz TEXT,fosfor TEXT,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS external_cache(kaynak TEXT NOT NULL,parametre_anahtari TEXT NOT NULL,ham_json TEXT NOT NULL,cekilme_tarihi TEXT NOT NULL,PRIMARY KEY(kaynak,parametre_anahtari));
CREATE TABLE IF NOT EXISTS kaynak_durum(kaynak TEXT PRIMARY KEY,kaynak_url TEXT,son_deneme TEXT,son_basari TEXT,durum TEXT);
CREATE TABLE IF NOT EXISTS crop_requirements(urun TEXT PRIMARY KEY,ph_min REAL,ph_max REAL,nem_min REAL,nem_max REAL,tuz_max TEXT,fosfor_min TEXT,kaynak TEXT NOT NULL,kaynak_url TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS cost_data(id INTEGER PRIMARY KEY,urun TEXT,il TEXT,kalem TEXT,tutar REAL,birim TEXT,yil INTEGER,kaynak TEXT NOT NULL,kaynak_url TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS price_data(id INTEGER PRIMARY KEY,urun TEXT,fiyat REAL,birim TEXT,tarih TEXT,kaynak TEXT NOT NULL,kaynak_url TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS yield_data(id INTEGER PRIMARY KEY,urun TEXT,il TEXT,yil INTEGER,verim_kg_da REAL,kaynak TEXT NOT NULL,kaynak_url TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS user_costs(parcel_id INTEGER NOT NULL REFERENCES parcels(id),urun TEXT NOT NULL,kalem TEXT NOT NULL,tutar REAL NOT NULL,PRIMARY KEY(parcel_id,urun,kalem));
CREATE TABLE IF NOT EXISTS seeds(id INTEGER PRIMARY KEY,name TEXT,description TEXT,region_note TEXT,kaynak TEXT NOT NULL,kaynak_url TEXT NOT NULL);");

    public static string Simdi() => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
}

public record Kullanici(long Id, string Email, string Ad);

public static class Oturum
{
    const int Tur = 200_000, Gun = 7;

    public static string Ozet(string parola, string saltHex) => Convert.ToHexString(
        Rfc2898DeriveBytes.Pbkdf2(parola, Convert.FromHexString(saltHex), Tur, HashAlgorithmName.SHA256, 32));

    public static long KullaniciEkle(string email, string parola, string ad)
    {
        var salt = Convert.ToHexString(RandomNumberGenerator.GetBytes(16));
        return Db.Calistir("INSERT INTO users(email,salt,hash,name) VALUES(@p0,@p1,@p2,@p3)", email, salt, Ozet(parola, salt), ad);
    }

    // Parolayı yeniler ve o kullanıcının açık oturumlarını kapatır.
    public static int ParolaDegistir(string email, string parola)
    {
        var s = Db.Oku("SELECT id FROM users WHERE email=@p0", email).FirstOrDefault();
        if (s == null) { Console.WriteLine("Kullanıcı bulunamadı."); return 2; }
        var salt = Convert.ToHexString(RandomNumberGenerator.GetBytes(16));
        Db.Calistir("UPDATE users SET salt=@p0,hash=@p1 WHERE id=@p2", salt, Ozet(parola, salt), s["id"]);
        Db.Calistir("DELETE FROM sessions WHERE user_id=@p0", s["id"]);
        Console.WriteLine("Parola değiştirildi.");
        return 0;
    }

    public static long? Dogrula(string email, string parola)
    {
        var s = Db.Oku("SELECT id,salt,hash FROM users WHERE email=@p0", email).FirstOrDefault();
        if (s == null) return null;
        var a = Convert.FromHexString(Ozet(parola, (string)s["salt"]!));
        return CryptographicOperations.FixedTimeEquals(a, Convert.FromHexString((string)s["hash"]!)) ? (long)s["id"]! : null;
    }

    public static void Ac(HttpContext h, long id)
    {
        var t = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        Db.Calistir("INSERT INTO sessions(token,user_id,created) VALUES(@p0,@p1,datetime('now'))", t, id);
        h.Response.Cookies.Append("token", t, new CookieOptions { HttpOnly = true, SameSite = SameSiteMode.Lax, MaxAge = TimeSpan.FromDays(Gun) });
    }

    public static void Kapat(HttpContext h)
    {
        Db.Calistir("DELETE FROM sessions WHERE token=@p0", h.Request.Cookies["token"]);
        h.Response.Cookies.Delete("token");
    }

    public static Kullanici? Kim(HttpContext h)
    {
        var s = Db.Oku(@"SELECT u.id,u.email,u.name FROM sessions s JOIN users u ON u.id=s.user_id
                         WHERE s.token=@p0 AND s.created>datetime('now','-7 days')", h.Request.Cookies["token"]).FirstOrDefault();
        return s == null ? null : new((long)s["id"]!, (string)s["email"]!, (string)s["name"]!);
    }
}

// Tüm adaptörlerin döndürdüğü ortak yapı. Deger null ise ekranda "Veri yok" yazılır.
public record Veri(JsonElement? Deger, string Birim, string Kaynak, string KaynakUrl, string? Tarih, bool OnbellekMi, string Notlar);

public static class DisKaynak
{
    public static readonly HttpClient Http = YeniIstemci();
    public static string LogYolu = "logs/dis-api.log";

    static HttpClient YeniIstemci()
    {
        var c = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("AkilliTarim-ders-projesi/1.0 (yerel ogrenci projesi)");
        return c;
    }

    public static void Log(string satir)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(LogYolu)!);
        lock (LogYolu) File.AppendAllText(LogYolu, $"{Db.Simdi()} {satir}\n");
    }

    static void Durum(string kaynak, string url, string durum, bool basari) => Db.Calistir(@"
        INSERT INTO kaynak_durum(kaynak,kaynak_url,son_deneme,son_basari,durum) VALUES(@p0,@p1,@p2,@p3,@p4)
        ON CONFLICT(kaynak) DO UPDATE SET son_deneme=excluded.son_deneme,durum=excluded.durum,
        son_basari=COALESCE(excluded.son_basari,son_basari)", kaynak, url, Db.Simdi(), basari ? Db.Simdi() : null, durum);

    public static void CacheYaz(string kaynak, string anahtar, string json) => Db.Calistir(@"
        INSERT INTO external_cache VALUES(@p0,@p1,@p2,@p3) ON CONFLICT(kaynak,parametre_anahtari)
        DO UPDATE SET ham_json=excluded.ham_json,cekilme_tarihi=excluded.cekilme_tarihi", kaynak, anahtar, json, Db.Simdi());

    public static (string json, string tarih)? CacheOku(string kaynak, string anahtar)
    {
        var s = Db.Oku("SELECT ham_json,cekilme_tarihi FROM external_cache WHERE kaynak=@p0 AND parametre_anahtari=@p1", kaynak, anahtar).FirstOrDefault();
        return s == null ? null : ((string)s["ham_json"]!, (string)s["cekilme_tarihi"]!);
    }

    public static void Basarili(string kaynak, string url) => Durum(kaynak, url, "çalışıyor", true);
    public static void Basarisiz(string kaynak, string url, bool onbellekVar) => Durum(kaynak, url, onbellekVar ? "önbellekte" : "erişilemiyor", false);

    // Kaynağı dener; başarısızsa son önbelleği, o da yoksa "Veri yok" döndürür. Hata loga yazılır, eski veri silinmez.
    public static async Task<Veri> Getir(string kaynak, string anahtar, string url, string kaynakUrl, string birim, string notlar, TimeSpan? tazelik = null)
    {
        var eski = CacheOku(kaynak, anahtar);
        if (tazelik != null && eski != null && DateTime.Now - DateTime.Parse(eski.Value.tarih) < tazelik)
            return new(JsonDocument.Parse(eski.Value.json).RootElement, birim, kaynak, kaynakUrl, eski.Value.tarih, false, notlar);
        var sw = Stopwatch.StartNew();
        try
        {
            // Yavaş kaynak sayfayı dondurmasın: 12 saniyede yanıt yoksa önbelleğe düşülür.
            using var sinir = new CancellationTokenSource(TimeSpan.FromSeconds(12));
            using var y = await Http.GetAsync(url, sinir.Token);
            Log($"{kaynak} GET durum={(int)y.StatusCode} sure={sw.ElapsedMilliseconds}ms");
            y.EnsureSuccessStatusCode();
            var json = await y.Content.ReadAsStringAsync();
            using var kontrol = JsonDocument.Parse(json);
            CacheYaz(kaynak, anahtar, json);
            Basarili(kaynak, kaynakUrl);
            return new(JsonDocument.Parse(json).RootElement, birim, kaynak, kaynakUrl, Db.Simdi(), false, notlar);
        }
        catch (Exception e)
        {
            Log($"{kaynak} HATA {e.GetType().Name}: {e.Message} sure={sw.ElapsedMilliseconds}ms");
            Basarisiz(kaynak, kaynakUrl, eski != null);
            if (eski != null) return new(JsonDocument.Parse(eski.Value.json).RootElement, birim, kaynak, kaynakUrl, eski.Value.tarih, true, notlar);
            return new(null, birim, kaynak, kaynakUrl, null, false, notlar);
        }
    }
}
