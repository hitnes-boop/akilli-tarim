# Canlı demo (yaklaşık 6 dakika)

Dersten önce, internet varken: `dotnet run -- hazirlik`, sonra `dotnet run`. Tarayıcı: http://localhost:5000. Hesap: `demo@ornek.com` / `tarla-fb465ac4805b`.

| Dakika | Sayfa | Söylenecek | Dikkat çekilecek |
|---|---|---|---|
| 0:00 | Giriş | Çiftçi kararını ölçmeden veriyor; biz kaynağı görünür karar desteği sunuyoruz. Yanlış parola deneyin. | Hata mesajı |
| 0:45 | Ana Sayfa | Çiftçi menü aramaz: "Bugün ne yapmalıyım?" sıradaki işi söyler. | Don uyarısı, adımlar |
| 1:30 | Yeni Tarla Ekle | Köşelere tıklanır, alan sunucuda hesaplanır, il/ilçe koordinattan bulunur. | Dönüm değeri |
| 2:15 | Tarlamın durumu | Sentinel-2'den 10 m hücrelerle NDVI. Uydu toprağın altını görmez. | Görüntü tarihi, bulut |
| 3:00 | **Doğrulama anı** | open-meteo.com API'sini yan sekmede açıp aynı günün sıcaklığını gösterin. NDVI hatasının nasıl yakalandığını anlatın (`KANIT.md`). | Sayıların eşleşmesi |
| 3:45 | Toprak ve öneri | Laboratuvar pH'ı girin; skor değişir. Değerlendirilemeyenler açıkça yazar. | Neden ve FAO bağlantısı |
| 4:30 | Kârım ne olur? | Verim TÜİK, fiyat TMO. Bir gideri değiştirip Hesapla'ya basın. Senaryolar 10 yıllık gerçek verimden. | Kâr, uyarı metni |
| 5:15 | Rapor | Çiftçi bu sayfayı yazdırıp mühendise götürür. | Kaynaklar, doz uyarısı |
| 5:40 | Veriler Nereden Geliyor? | Her kaynağın durumu açık. Yapay zekâ ve 10 m analizi yok, açıkça söylenir. | Durum etiketleri |

## İnternet giderse

Sistemi kapatmayın. Sayfalar "önbellekten, tarih ..." etiketiyle açılır; bunu gösterip gerçekten çekilmiş veri olduğunu söyleyin. Harita altlığı görünmez, NDVI hücreleri görünür. Yeni parsel için uydu ve toprak verisi gelmez; demo parselini kullanın. Doğrulama anını `KANIT.md` tablosuyla yapın.

## Sorulursa

- Maliyet neden girilen değer? Konya için kalem kalem resmî tablo bulunamadı; uydurmadık.
- Kâr neden anında değişmiyor? Ders kuralı gereği JavaScript yok.
